// 屏蔽普通日志和信息
console.log = function() {};
console.info = function() {};
document.addEventListener("DOMContentLoaded", function() {
    // 默认配置（使用毫秒）
    const DEFAULT_CONFIG = {
        LOAD_TIMEOUT_MS: 10000, // 10秒
        STALL_TIMEOUT_MS: 10000, // 10秒
        MAX_RETRY_ROUNDS: 2, // 2轮
        SEARCH_DEBOUNCE_MS: 300, // 300毫秒
        PLAYLIST_REFRESH_INTERVAL: 1000 * 60 * 30, // 30分钟
        AUTO_REFRESH_ENABLED: true, // 启用自动刷新
        BLACKLIST_URL: chrome.runtime.getURL('blacklist.txt'), // 黑名单文件URL
        EPG_ENABLED: false, // 默认关闭EPG
        EPG_URL: '', // 默认EPG URL
        MARQUEE_SPEED: 100, // 跑马灯速度 (像素/秒)
        MARQUEE_COLOR: '#ffd700', // 跑马灯字体颜色
        MARQUEE_FONT_SIZE: '18px' // 跑马灯字体大小
    };
    // 实际使用的配置（会被用户设置覆盖）
    const CONFIG = { ...DEFAULT_CONFIG };
    const MIN_EPG_REFRESH_INTERVAL = 10 * 60 * 1000; // 最小EPG刷新间隔: 10分钟
    const state = {
        player: null,
        isPlaying: false,
        videoUrl: "",
        baseUrl: "",
        currentPlaylist: [],
        originalPlaylistUrl: "",
        currentPlaylistIndex: -1,
        isM3UPlaylist: false,
        streamInfo: {
            resolution: "未知",
            type: "未知"
        },
        loadRequestId: 0,
        timers: {
            load: null,
            stall: null,
            controls: null,
            hidePlaylist: null,
            searchDebounce: null,
            refreshPlaylist: null,
            epgRefresh: null // 新增: EPG刷新定时器
        },
        currentChannelInfo: {
            title: "",
            originalIndex: -1,
            urls: []
        },
        blacklist: [], // 黑名单关键词数组
        isBlacklistLoaded: false, // 黑名单是否已加载
        epgData: {}, // EPG数据: {channelId: [{start, stop, title}]}
        channelMap: {}, // name.lower -> id
        epgExpiryTime: 0, // EPG到期时间戳
        lastEpgRefreshTime: 0, // 上次EPG刷新时间戳
        isMarqueeActive: false // 新增: 跑马灯是否活跃标志
    };
    const UI = {
        videoPlayer: document.getElementById("videoPlayer"),
        videoInfo: document.getElementById("videoInfo"),
        videoContainer: document.querySelector(".video-container"),
        controls: document.getElementById("controls"),
        playPauseBtn: document.getElementById("playPauseBtn"),
        backBtn: document.getElementById("backBtn"),
        prevChannelBtn: document.getElementById("prevChannelBtn"),
        nextChannelBtn: document.getElementById("nextChannelBtn"),
        volumeBtn: document.getElementById("volumeBtn"),
        fullscreenBtn: document.getElementById("fullscreenBtn"),
        playlistBtn: document.getElementById("playlistBtn"),
        closePlaylistBtn: document.getElementById("closePlaylistBtn"),
        clearSearchBtn: document.getElementById("clearSearchBtn"),
        infoBtn: null,
        progress: document.getElementById("progress"),
        progressBar: document.getElementById("progressBar"),
        timeDisplay: document.getElementById("time"),
        volumeSlider: document.getElementById("volumeSlider"),
        volumeProgress: document.getElementById("volumeProgress"),
        volumeContainer: document.querySelector(".volume-container"),
        playlistContainer: document.getElementById("playlist-container"),
        playlistItems: document.getElementById("playlist-items"),
        playlistSearchInput: document.getElementById("playlist-search-input"),
        loading: document.getElementById("loading"),
        errorMessage: document.getElementById("errorMessage"),
        infoPanel: null,
        switchSourceBtn: null,
        epgBtn: null
    };
    let epgPopup = null;
    // ==================== 新增：键盘事件处理函数 ====================
    function handleKeyDown(e) {
        // 如果播放列表可见，优先处理播放列表相关快捷键
        if (!UI.playlistContainer.classList.contains("hidden")) {
            // ESC键：关闭播放列表
            if (e.code === 'Escape' || e.key === 'Escape' || e.keyCode === 27) {
                e.preventDefault();
                closePlaylist();
                return;
            }
            // 回车键：播放当前选中的项目
            if ((e.code === 'Enter' || e.key === 'Enter' || e.keyCode === 13)) {
                e.preventDefault();
                playSelectedSearchResult();
                // 不移除焦点，保持播放列表控制状态
                return;
            }
            // 上下箭头：在搜索结果中导航
            if (e.code === 'ArrowUp' || e.code === 'ArrowDown') {
                e.preventDefault();
                hideEpgPopup(); // 隐藏旧的
                navigateSearchResults(e.code === 'ArrowUp' ? -1 : 1);
                const selected = UI.playlistItems.querySelector('.selected');
                if (selected) {
                    const index = parseInt(selected.dataset.index);
                    const item = state.currentPlaylist[index];
                    showEpgPopup(selected, item);
                }
                return;
            }
            // 搜索框特殊处理
            if (e.target === UI.playlistSearchInput) {
                // 允许在搜索框中正常输入
                return;
            }
            // 其他按键在播放列表可见时不处理全局快捷键
            // 防止上下箭头变成音量调节
            if (e.code === 'ArrowUp' || e.code === 'ArrowDown') {
                e.preventDefault();
                return;
            }
            // 左右箭头：在播放列表打开时不处理，保持静默
            if (e.code === 'ArrowLeft' || e.code === 'ArrowRight') {
                e.preventDefault();
                return;
            }
        }
        // 全局快捷键处理（仅当播放列表不可见时）
        // / 键：调出播放列表并定位搜索框
        if (e.key === '/' || e.code === 'Slash') {
            e.preventDefault(); // 防止浏览器搜索功能
            focusPlaylistSearch();
            showKeyFeedback('搜索播放列表');
        }
        // 空格键：播放/暂停
        else if (e.code === 'Space' || e.key === ' ' || e.keyCode === 32) {
            e.preventDefault(); // 防止空格键滚动页面
            togglePlayPause();
            // 显示控制栏反馈
            showControls();
            // 短暂显示一个视觉反馈
            showKeyFeedback('空格键: ' + (UI.videoPlayer.paused ? '播放' : '暂停'));
        }
        // 上箭头键：增加音量（仅当播放列表不可见时）
        else if (e.code === 'ArrowUp') {
            e.preventDefault();
            const result = adjustVolumeByArrow(0.05); // 每次增加5%
            if (result.changed) {
                showKeyFeedback(`音量: ${result.newVolume}%`);
                showControls();
            } else {
                showKeyFeedback(`音量已达最大值: 100%`);
            }
        }
        // 下箭头键：减少音量（仅当播放列表不可见时）
        else if (e.code === 'ArrowDown') {
            e.preventDefault();
            const result = adjustVolumeByArrow(-0.05); // 每次减少5%
            if (result.changed) {
                showKeyFeedback(`音量: ${result.newVolume}%`);
                showControls();
            } else {
                showKeyFeedback(`音量已达最小值: 0%`);
            }
        }
        // 左箭头键：快退5秒（仅当播放列表不可见时）
        else if (e.code === 'ArrowLeft') {
            e.preventDefault();
            if (UI.videoPlayer.duration && !isNaN(UI.videoPlayer.duration)) {
                UI.videoPlayer.currentTime = Math.max(0, UI.videoPlayer.currentTime - 5);
                showKeyFeedback('快退: 5秒');
                showControls();
            }
        }
        // 右箭头键：快进5秒（仅当播放列表不可见时）
        else if (e.code === 'ArrowRight') {
            e.preventDefault();
            if (UI.videoPlayer.duration && !isNaN(UI.videoPlayer.duration)) {
                UI.videoPlayer.currentTime = Math.min(UI.videoPlayer.duration, UI.videoPlayer.currentTime + 5);
                showKeyFeedback('快进: 5秒');
                showControls();
            }
        }
        // F键：全屏切换
        else if (e.code === 'KeyF' || e.key === 'f') {
            e.preventDefault();
            toggleFullscreen();
            showKeyFeedback('全屏切换');
            showControls();
        }
        // M键：静音切换
        else if (e.code === 'KeyM' || e.key === 'm') {
            e.preventDefault();
            toggleMute();
            showKeyFeedback('静音: ' + (UI.videoPlayer.muted ? '关闭' : '开启'));
            showControls();
        }
        // P键：播放列表切换
        else if (e.code === 'KeyP' || e.key === 'p') {
            e.preventDefault();
            togglePlaylistUI();
            showKeyFeedback('播放列表');
            showControls();
        }
        // 左方括号键：上一个频道
        else if (e.code === 'BracketLeft' || e.key === '[') {
            e.preventDefault();
            switchToPrevChannel();
            //showKeyFeedback('上一个频道');
            showControls();
        }
        // 右方括号键：下一个频道
        else if (e.code === 'BracketRight' || e.key === ']') {
            e.preventDefault();
            switchToNextChannel();
            //showKeyFeedback('下一个频道');
            showControls();
        }
        // S键：手动换源
        else if (e.code === 'KeyS' || e.key === 's') {
            e.preventDefault();
            manualSwitchToNextSource();
            showKeyFeedback('手动换源');
            showControls();
        }
        // I键：显示/隐藏信息面板
        else if (e.code === 'KeyI' || e.key === 'i') {
            e.preventDefault();
            toggleVideoInfo();
            showKeyFeedback('信息面板');
            showControls();
        }
        // E键：显示EPG跑马灯
        else if (e.code === 'KeyE' || e.key === 'e') {
            e.preventDefault();
            showEpgMarquee();
            showKeyFeedback('节目信息');
            showControls();
        }
    }
    // 新增：关闭播放列表
    function closePlaylist() {
        // 直接关闭播放列表，不通过 togglePlaylistUI 递归
        UI.playlistContainer.classList.add("hidden");
        UI.playlistSearchInput.blur();
        UI.playlistSearchInput.style.border = "";
        UI.playlistSearchInput.style.boxShadow = "";
        // 清除选中项
        const selectedItem = UI.playlistItems.querySelector('.selected');
        if (selectedItem) {
            selectedItem.classList.remove('selected');
        }
        hideEpgPopup(); // 关闭EPG弹出框
        showKeyFeedback('关闭列表');
        showControls();
    }
    // 新增：在搜索结果中导航
    function navigateSearchResults(direction) {
        const searchTerm = UI.playlistSearchInput.value;
        const filteredItems = Array.from(UI.playlistItems.children)
            .filter(item => item.style.display !== 'none');
        if (filteredItems.length === 0) return;
        // 查找当前选中的项目
        let currentIndex = -1;
        for (let i = 0; i < filteredItems.length; i++) {
            if (filteredItems[i].classList.contains('selected')) {
                currentIndex = i;
                break;
            }
        }
        // 计算新的选中索引
        let newIndex;
        if (currentIndex === -1) {
            // 没有选中项，选择第一个或最后一个
            newIndex = direction > 0 ? 0 : filteredItems.length - 1;
        } else {
            newIndex = currentIndex + direction;
            if (newIndex < 0) newIndex = filteredItems.length - 1;
            if (newIndex >= filteredItems.length) newIndex = 0;
        }
        // 移除旧的选中样式
        filteredItems.forEach(item => item.classList.remove('selected'));
        // 添加新的选中样式
        filteredItems[newIndex].classList.add('selected');
        // 滚动到选中项
        filteredItems[newIndex].scrollIntoView({
            behavior: 'smooth',
            block: 'nearest'
        });
        // 显示反馈
        const itemText = filteredItems[newIndex].textContent;
        showKeyFeedback(`选中: ${itemText}`);
        // 确保焦点不在搜索框时，播放列表仍然保持键盘控制
        maintainPlaylistFocus();
    }
    // 新增：保持播放列表焦点状态
    function maintainPlaylistFocus() {
        // 如果播放列表可见但焦点不在任何可输入元素上，给播放列表一个虚拟焦点
        if (!UI.playlistContainer.classList.contains("hidden") &&
            document.activeElement !== UI.playlistSearchInput &&
            !document.activeElement.classList.contains('playlist-item')) {
            // 可以给播放列表容器添加一个焦点状态样式
            UI.playlistContainer.classList.add('has-focus');
            // 或者给选中的播放列表项添加焦点
            const selectedItem = UI.playlistItems.querySelector('.selected');
            if (selectedItem) {
                selectedItem.focus();
            }
        }
    }
    // 新增：播放选中的搜索结果
    function playSelectedSearchResult() {
        const selectedItem = UI.playlistItems.querySelector('.selected');
        if (selectedItem) {
            const index = parseInt(selectedItem.dataset.index);
            if (!isNaN(index)) {
                // 播放选中的项目
                playPlaylistItem(index);
                // 播放后保持选中状态，以便继续使用上下箭头导航
                setTimeout(() => {
                    maintainPlaylistFocus();
                }, 100);
            }
        } else {
            // 如果没有选中项，提示用户
            showKeyFeedback('请先用上下箭头选择一个频道');
        }
    }
    // 新增：聚焦到播放列表搜索框
    function focusPlaylistSearch() {
        // 首先确保播放列表是可见的
        if (UI.playlistContainer.classList.contains("hidden")) {
            togglePlaylistUI(true);
        }
        // 等待一小段时间确保DOM已更新
        setTimeout(() => {
            // 聚焦到搜索框
            UI.playlistSearchInput.focus();
            // 选中所有文本以便直接输入
            UI.playlistSearchInput.select();
            // 添加一个聚焦样式
            UI.playlistSearchInput.style.border = "2px solid #4dabf7";
            UI.playlistSearchInput.style.boxShadow = "0 0 0 3px rgba(77, 171, 247, 0.3)";
            // 显示搜索框位置提示
            //highlightSearchBox();
            // 清除任何现有的选中项
            const selectedItem = UI.playlistItems.querySelector('.selected');
            if (selectedItem) {
                selectedItem.classList.remove('selected');
            }
        }, 50);
    }
    // 新增：高亮显示搜索框
    function highlightSearchBox() {
        // 移除现有的高亮元素
        const existingHighlight = document.querySelector('.search-highlight');
        if (existingHighlight) {
            existingHighlight.remove();
        }
        // 创建高亮元素
        const highlight = document.createElement('div');
        highlight.className = 'search-highlight';
        highlight.innerHTML = '✨ 搜索框已激活，输入关键词搜索频道';
        // 定位在搜索框旁边
        const rect = UI.playlistSearchInput.getBoundingClientRect();
        highlight.style.cssText = `
            position: fixed;
            top: ${rect.top - 40}px;
            left: ${rect.left}px;
            background: linear-gradient(135deg, #4dabf7, #339af0);
            color: white;
            padding: 8px 16px;
            border-radius: 6px;
            font-size: 13px;
            font-weight: bold;
            z-index: 2000;
            pointer-events: none;
            opacity: 1;
            transition: opacity 0.3s ease;
            box-shadow: 0 4px 12px rgba(77, 171, 247, 0.4);
        `;
        // 添加一个箭头指向搜索框
        highlight.innerHTML += `
            <div style="position: absolute; bottom: -8px; left: 20px; width: 0; height: 0; border-left: 8px solid transparent; border-right: 8px solid transparent; border-top: 8px solid #339af0;"></div>
        `;
        document.body.appendChild(highlight);
        // 2秒后淡出并移除
        setTimeout(() => {
            highlight.style.opacity = '0';
            setTimeout(() => {
                if (highlight.parentNode) {
                    highlight.parentNode.removeChild(highlight);
                }
            }, 300);
        }, 2000);
    }
    // 修改：使用箭头键调整音量，返回调整结果
    function adjustVolumeByArrow(delta) {
        const oldVolume = UI.videoPlayer.volume;
        let newVolume = oldVolume + delta;
        // 限制在0-1之间
        newVolume = Math.max(0, Math.min(1, newVolume));
        // 检查是否实际发生了变化
        const changed = Math.abs(newVolume - oldVolume) > 0.001;
        if (changed) {
            UI.videoPlayer.volume = newVolume;
            UI.videoPlayer.muted = (newVolume === 0); // 如果音量为0，则静音
            // 更新音量条
            UI.volumeProgress.style.width = newVolume * 100 + "%";
            updateVolumeIcon();
            // 保存音量设置
            chrome.storage.local.set({
                volume: newVolume
            });
        }
        // 返回调整结果
        return {
            changed: changed,
            oldVolume: oldVolume * 100,
            newVolume: Math.round(newVolume * 100)
        };
    }
    // 新增：键盘操作视觉反馈
    function showKeyFeedback(message) {
        // 移除现有的反馈元素
        const existingFeedback = document.querySelector('.key-feedback');
        if (existingFeedback) {
            existingFeedback.remove();
        }
        // 创建反馈元素
        const feedback = document.createElement('div');
        feedback.className = 'key-feedback';
        feedback.textContent = message;
        // 样式设置
        feedback.style.cssText = `
            position: fixed;
            bottom: 100px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(0, 100, 200, 0.9);
            color: white;
            padding: 10px 20px;
            border-radius: 25px;
            font-size: 14px;
            font-weight: bold;
            z-index: 1001;
            pointer-events: none;
            opacity: 1;
            box-shadow: 0 4px 12px rgba(0, 100, 200, 0.3);
            min-width: 120px;
            text-align: center;
        `;
        document.body.appendChild(feedback);
        // 1秒后淡出并移除
        setTimeout(() => {
            feedback.style.opacity = '0';
            feedback.style.transition = 'opacity 0.3s ease';
            setTimeout(() => {
                if (feedback.parentNode) {
                    feedback.parentNode.removeChild(feedback);
                }
            }, 300);
        }, 1000);
    }
    // ==================== 键盘事件处理结束 ====================
    // 新增：加载EPG数据
    async function loadEPG() {
        if (!CONFIG.EPG_ENABLED) return;
        try {
            state.lastEpgRefreshTime = Date.now(); // 更新上次刷新时间
            console.log('[EPG] 开始加载:', CONFIG.EPG_URL);
            const response = await fetch(CONFIG.EPG_URL);
            if (!response.ok) {
                throw new Error(`HTTP ${response.status} - ${response.statusText}`);
            }
            let text;
            // 判断是否需要解压（根据 Content-Type 或文件后缀）
            const contentType = response.headers.get('content-type') || '';
            const isGzipped = 
                contentType.includes('gzip') || 
                contentType.includes('application/gzip') ||
                CONFIG.EPG_URL.toLowerCase().endsWith('.gz');
            if (isGzipped && 'DecompressionStream' in window) {
                console.log('[EPG] 检测到 gzip 压缩，使用 DecompressionStream 解压');
                const buffer = await response.arrayBuffer();
                const decompressedStream = new Response(
                    new Blob([buffer]).stream().pipeThrough(
                        new DecompressionStream('gzip')
                    )
                );
                text = await decompressedStream.text();
            } else {
                // 普通文本或已自动解压的情况
                text = await response.text();
            }
            const parser = new DOMParser();
            const xml = parser.parseFromString(text, 'text/xml');
            // 检查解析是否成功
            if (xml.getElementsByTagName('parsererror').length > 0) {
                throw new Error('XML 解析失败，可能文件格式错误或未正确解压');
            }
            // ==================== 原有解析逻辑 ====================
            const channels = xml.getElementsByTagName('channel');
            state.channelMap = {}; // name.lower -> id (备用匹配)
            for (let ch of channels) {
                const id = ch.getAttribute('id');
                const displayName = ch.querySelector('display-name')?.textContent?.trim();
                if (displayName && id) {
                    state.channelMap[displayName.toLowerCase()] = id;
                }
            }
            const programmes = xml.getElementsByTagName('programme');
            state.epgData = {};
            for (let prog of programmes) {
                const channelId = prog.getAttribute('channel');
                if (!state.epgData[channelId]) state.epgData[channelId] = [];
                const startStr = prog.getAttribute('start');
                const stopStr = prog.getAttribute('stop');
                const start = parseEpgTime(startStr);
                const stop = parseEpgTime(stopStr);
                const titleElem = prog.querySelector('title');
                const title = titleElem?.textContent?.trim() || '未知节目';
                state.epgData[channelId].push({ start, stop, title });
            }
            // 按开始时间排序
            for (let id in state.epgData) {
                state.epgData[id].sort((a, b) => a.start - b.start);
            }
            console.log(`[EPG] 加载完成，共 ${Object.keys(state.epgData).length} 个频道节目表`);
            // 新增: 计算EPG到期时间（最晚节目结束时间）
            calculateEpgExpiry();
            // 新增: 启动到期前刷新定时器
            scheduleEpgRefresh();
        } catch (err) {
            console.error('[EPG] 加载失败:', err);
            // 可选：提示用户
            // showNotification('EPG数据加载失败，请检查网络或URL', 4000);
        }
    }
    // 新增：计算EPG到期时间
    function calculateEpgExpiry() {
        let maxStop = 0;
        for (let id in state.epgData) {
            const programs = state.epgData[id];
            if (programs.length > 0) {
                const lastStop = programs[programs.length - 1].stop;
                if (lastStop > maxStop) maxStop = lastStop;
            }
        }
        state.epgExpiryTime = maxStop;
        console.log(`[EPG] 计算到期时间: ${new Date(maxStop).toLocaleString()}`);
    }
    // 新增：调度EPG刷新（到期前1小时刷新）
    function scheduleEpgRefresh() {
        // 1. 清理现有定时器，确保不重叠
        if (state.timers.epgRefresh) {
            clearTimeout(state.timers.epgRefresh);
            state.timers.epgRefresh = null;
        }
        // 2. 前置检查
        if (!CONFIG.EPG_ENABLED || state.epgExpiryTime <= 0) return;
        const now = Date.now();
        const timeToExpiry = state.epgExpiryTime - now;
        // 计算触发更新的目标时间点：过期前1小时 (3600000 ms)
        // 如果现在已经进入了过期前1小时，则目标延迟为 0
        const targetTriggerDelay = Math.max(timeToExpiry - 3600000, 0);
        // 设置触发器
        state.timers.epgRefresh = setTimeout(() => {
            const currentTime = Date.now();
            const timeSinceLastRefresh = currentTime - state.lastEpgRefreshTime;
            // 3. 触发时检查：是否满足最小刷新间隔
            if (timeSinceLastRefresh >= MIN_EPG_REFRESH_INTERVAL) {
                console.log('[EPG] 满足刷新条件（进入过期预警期且已过最小间隔），开始更新...');
                loadEPG();
            } else {
                // 4. 不满足间隔：计算还需等待多久并安排补跳
                const remainingWait = MIN_EPG_REFRESH_INTERVAL - timeSinceLastRefresh;
                console.log(`[EPG] 触发太频繁，等待最小间隔：还需 ${Math.round(remainingWait / 1000)} 秒后补刷`);
                // 覆盖当前的 timer，确保最后一次补刷能执行
                state.timers.epgRefresh = setTimeout(() => {
                    console.log('[EPG] 最小间隔已满，执行补刷...');
                    loadEPG();
                }, remainingWait);
            }
        }, targetTriggerDelay);
        if (targetTriggerDelay > 0) {
            console.log(`[EPG] 调度成功：将于 ${Math.round(targetTriggerDelay / 3600000 * 10) / 10} 小时后尝试触发更新`);
        } else {
            console.log('[EPG] 处于过期预警期，尝试立即触发检查');
        }
    }
    // 新增：解析EPG时间字符串到时间戳
    function parseEpgTime(timeStr) {
        if (!timeStr) return 0;
        const year = timeStr.substring(0, 4);
        const month = timeStr.substring(4, 6);
        const day = timeStr.substring(6, 8);
        const hour = timeStr.substring(8, 10);
        const min = timeStr.substring(10, 12);
        const sec = timeStr.substring(12, 14);
        const tz = timeStr.substring(14).trim() || '+0000';
        const dateStr = `${year}-${month}-${day}T${hour}:${min}:${sec}${tz.replace(' ', '')}`;
        const ts = Date.parse(dateStr);
        return isNaN(ts) ? 0 : ts;
    }
    // 新增：格式化时间戳为本地时间字符串
    function formatEpgTime(ts) {
        if (!ts) return '未知';
        const date = new Date(ts);
        return date.toLocaleTimeString('zh-CN', {hour: '2-digit', minute: '2-digit'});
    }
    /**
     * 精准清洗频道名称（修复CCTV10科教频道匹配问题）
     * @param {string} name - 原始频道名称
     * @returns {string} 清洗后的名称
     */
    function cleanName(name) {
        if (!name || typeof name !== 'string') return "";
        let cleaned = name
            .toLowerCase()
            .replace(/\s+/g, "")
            .replace(/[^\w\+\-\u4e00-\u9fa5]/g, "")
            .trim();
        // 统一符号
        cleaned = cleaned.replace(/plus/g, '+');
        console.log(`[EPG调试] 清洗: "${name}" -> "${cleaned}"`);
        // ========== 特殊频道映射表 ==========
        const specialChannels = {
            // 4K/8K超高清频道
            'cctv4k': 'cctv4k',
            'cctv8k': 'cctv8k',
            'cctv4k超高清': 'cctv4k',
            'cctv8k超高清': 'cctv8k',
            'cctv-4k': 'cctv4k',
            'cctv-8k': 'cctv8k',
            // 错误名称修正
            'cctv-': 'cctv',
            'cctv_': 'cctv',
            'cctv ': 'cctv',
            // 其他特殊处理
            'cctv4k+': 'cctv4k+',
            'cctv8k+': 'cctv8k+'
        };
        // 先检查特殊频道映射
        if (specialChannels[cleaned]) {
            console.log(`[EPG调试] 特殊频道映射: "${cleaned}" -> "${specialChannels[cleaned]}"`);
            return specialChannels[cleaned];
        }
        // ========== 正则匹配 ==========
        // 1. 4K/8K频道（优先于数字频道）
        const hdMatch = cleaned.match(/^(cctv|channel|tv)[\-_]?(4k|8k)(\+)?$/i);
        if (hdMatch) {
            const result = hdMatch[1] + hdMatch[2] + (hdMatch[3] || '');
            console.log(`[EPG调试] 4K/8K频道: "${cleaned}" -> "${result}"`);
            return result;
        }
        // 2. 带+号的数字频道
        const plusMatch = cleaned.match(/^(cctv|channel|tv)[\-_]?(\d+)\+$/i);
        if (plusMatch) {
            const result = plusMatch[1] + plusMatch[2] + '+';
            console.log(`[EPG调试] 带+号频道: "${cleaned}" -> "${result}"`);
            return result;
        }
        // 3. 普通数字频道
        const numberMatch = cleaned.match(/^(cctv|channel|tv)[\-_]?(\d+)/i);
        if (numberMatch) {
            const result = numberMatch[1] + numberMatch[2];
            console.log(`[EPG调试] 数字频道: "${cleaned}" -> "${result}"`);
            return result;
        }
        // 4. CCTV+中文
        if (cleaned.startsWith('cctv')) {
            const withoutCctv = cleaned.substring(4);
            if (withoutCctv && /^[\u4e00-\u9fa5]+$/.test(withoutCctv)) {
                console.log(`[EPG调试] CCTV+中文: "${cleaned}" -> "${withoutCctv}"`);
                return withoutCctv;
            }
        }
        // 5. 后缀处理
        const suffixes = [
            '超高清', '高清', '标清', 'hd', 'sd', 'fhd', 'uhd',
            '台', '频道', 'channel', 'tv'
        ];
        for (const suffix of suffixes) {
            if (cleaned.endsWith(suffix)) {
                const result = cleaned.slice(0, -suffix.length);
                console.log(`[EPG调试] 去除后缀: "${cleaned}" -> "${result}"`);
                // 如果去除后缀后是空字符串，返回原始
                if (!result) {
                    console.log(`[EPG调试] 警告: 去除后缀后为空，返回原始: "${cleaned}"`);
                    return cleaned;
                }
                return result;
            }
        }
        console.log(`[EPG调试] 最终结果: "${cleaned}"`);
        return cleaned;
    }
    // 新增：获取频道ID
    function getChannelId(item) {
        let prechId = item.attributes ? item.attributes['tvg-id'] : '';
		let chId = cleanName(prechId);
        if (!chId) {
            const nameLower = cleanName(item.title || '');
            chId = state.channelMap[nameLower] || nameLower; // 如果没有匹配，用name作为fallback
        }
        return chId;
    }
    // 新增：获取当前节目
    function getCurrentProgram(programs) {
        const now = Date.now();
        return programs.find(p => now >= p.start && now < p.stop) || null;
    }
    // 新增：获取接下来几个节目
    function getNextPrograms(programs, num = 3) {
        const now = Date.now();
        const future = programs.filter(p => p.start > now).sort((a, b) => a.start - b.start);
        return future.slice(0, num);
    }
    // 新增：显示EPG弹出框（智能自适应位置，避免被边缘挡住）
    function showEpgPopup(itemEl, item) {
        if (!CONFIG.EPG_ENABLED) return;
        if (epgPopup) hideEpgPopup();
        const chId = getChannelId(item);
        const programs = state.epgData[chId] || [];
        const current = getCurrentProgram(programs);
        const next = getNextPrograms(programs, 3);
        if (!current && next.length === 0) return;
        epgPopup = document.createElement('div');
        epgPopup.className = 'epg-popup';
        let html = '';
        if (current) {
            html += `<span style="color: #4CAF50; font-weight: bold;">当前:</span> ${current.title} (${formatEpgTime(current.start)} - ${formatEpgTime(current.stop)})<br>`;
        }
        next.forEach((p, i) => {
            html += `<span style="color: #FFA500; font-weight: bold;">稍后:</span> ${p.title} (${formatEpgTime(p.start)} - ${formatEpgTime(p.stop)})<br>`;
        });
        epgPopup.innerHTML = html;
        // 先添加到 DOM 以获取尺寸（但先隐藏）
        epgPopup.style.visibility = 'hidden';
        document.body.appendChild(epgPopup);
        // 延迟一帧，确保布局稳定后再计算位置
        requestAnimationFrame(() => {
            const rect = itemEl.getBoundingClientRect();
            const popupRect = epgPopup.getBoundingClientRect();
            const viewportWidth = window.innerWidth;
            const viewportHeight = window.innerHeight;
            const margin = 12; // 更大一点的安全边距
            let left = rect.left - popupRect.width - margin;
            let top = rect.top;
            // 水平：左侧空间不够 → 移到右侧
            if (left < margin) {
                left = rect.right + margin;
                // 右侧也放不下？尽量靠右但不超
                if (left + popupRect.width > viewportWidth - margin) {
                    left = viewportWidth - popupRect.width - margin;
                }
            }
            // 垂直方向智能调整（最关键）
            const spaceBelow = viewportHeight - rect.bottom;     // 下方剩余空间
            const spaceAbove = rect.top;                          // 上方剩余空间
            // 如果下方空间足够放完整弹出框，保持原位置
            if (spaceBelow >= popupRect.height + margin) {
                top = rect.top;
            }
            // 下方不够，但上方空间足够 → 向上贴频道顶部
            else if (spaceAbove >= popupRect.height + margin) {
                top = rect.top - popupRect.height - margin;
            }
            // 上下都不够 → 尽量居中显示在频道附近，并允许滚动
            else {
                // 优先向上对齐频道顶部
                top = rect.top - popupRect.height - margin;
                // 如果还是超上界，强制贴顶
                if (top < margin) {
                    top = margin;
                }
            }
            // 最终边界保护
            top = Math.max(margin, Math.min(top, viewportHeight - popupRect.height - margin));
            // 应用位置并显示
            epgPopup.style.position = 'fixed';
            epgPopup.style.left = `${left}px`;
            epgPopup.style.top = `${top}px`;
            epgPopup.style.visibility = 'visible';
            // 增强样式：限制高度 + 可滚动
            epgPopup.style.maxHeight = `${viewportHeight * 0.75}px`; // 最多占视口 75%
            epgPopup.style.overflowY = 'auto';
            epgPopup.style.maxWidth = '340px';
            epgPopup.style.minWidth = '240px';
            epgPopup.style.background = 'rgba(0,0,0,0.88)';
            epgPopup.style.color = 'white';
            epgPopup.style.padding = '12px';
            epgPopup.style.borderRadius = '8px';
            epgPopup.style.zIndex = '1001';
            epgPopup.style.boxShadow = '0 6px 20px rgba(0,0,0,0.6)';
        });
    }
    // 新增：隐藏EPG弹出框
    function hideEpgPopup() {
        if (epgPopup) {
            epgPopup.remove();
            epgPopup = null;
        }
    }
    // 新增：显示EPG跑马灯（修复版 - 完整显示两遍 + 中间停顿）
    function showEpgMarquee() {
        if (!CONFIG.EPG_ENABLED || state.currentPlaylistIndex === -1) {
            showNotification('EPG未启用或无当前频道', 2000);
            return;
        }
        // 防止重复触发
        if (state.isMarqueeActive) {
            showNotification('节目信息已在显示中', 1500);
            return;
        }
        state.isMarqueeActive = true;
    
        const item = state.currentPlaylist[state.currentPlaylistIndex];
        const chId = getChannelId(item);
        const programs = state.epgData[chId] || [];
        const current = getCurrentProgram(programs);
        const next = getNextPrograms(programs, 2);
        const chName = state.currentChannelInfo?.title || 
                       state.currentPlaylist[state.currentPlaylistIndex]?.title || 
                       "未知频道";
    
        // --- 1. 构建富文本内容 ---
        let htmlContent = '';
        const spacing = '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'; 
    
        if (current) {
            htmlContent += `
                <span style="color: #FFFFFF;">【${chName}】 </span> 
                <span style="color: #00FFCC; font-weight: bold;">正在播放:</span> 
                <span style="color: #FFFFFF;">《${current.title}》</span> 
                <span style="color: #AAAAAA; font-size: 0.9em;">(${formatEpgTime(current.start)} - ${formatEpgTime(current.stop)})</span>${spacing}`;
        }
    
        next.forEach((p, i) => {
            let label, labelColor, labelOpacity;
            if (i === 0) {
                label = '下一个';
                labelColor = '#FFD700';
                labelOpacity = '1.0';
            } else {
                label = '稍后';
                labelColor = '#FFA500';
                labelOpacity = '0.7';
            }
            htmlContent += `
                <span style="color: ${labelColor}; opacity: ${labelOpacity}; font-weight: 500;">${label}:</span> 
                <span style="color: #EEEEEE;">《${p.title}》</span> 
                <span style="color: #888888; font-size: 0.9em;">(${formatEpgTime(p.start)} - ${formatEpgTime(p.stop)})</span>${spacing}`;
        });
    
        if (!htmlContent) {
            htmlContent = '<span style="color: #FFFFFF;">当前频道无节目信息</span>';
        }
    
        // --- 2. 测量文本实际像素宽度 (核心新逻辑) ---
        const measurer = document.createElement('span');
        measurer.style.cssText = `
            position: absolute;
            visibility: hidden;
            white-space: nowrap;
            font-size: ${CONFIG.MARQUEE_FONT_SIZE};
            font-weight: 500;
        `;
        measurer.innerHTML = htmlContent;
        document.body.appendChild(measurer);
        const textWidth = measurer.offsetWidth;
        document.body.removeChild(measurer);
    
        // --- 3. 计算动画时长 (基于恒定像素速度) ---
        const containerWidth = window.innerWidth;
        const totalDistance = containerWidth + textWidth; // 总滑行路程
    
        // 定义恒定速度：每秒移动多少像素
        // 建议：100 为中速，150 为快速，80 为慢速
        // 如果你想继续用 CONFIG，可以设为 CONFIG.MARQUEE_SPEED || 120
        const pixelsPerSecond = CONFIG.MARQUEE_SPEED || 120; 
        
        const scrollDuration = totalDistance / pixelsPerSecond;
    
        // --- 4. 创建跑马灯容器 ---
        const marquee = document.createElement('div');
        marquee.className = 'epg-marquee';
        marquee.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 40px;
            background: rgb(20, 20, 20);
            z-index: 1000;
            display: flex;
            align-items: center;
            overflow: hidden;
            box-shadow: none;
        `;
    
        const span = document.createElement('span');
        span.innerHTML = htmlContent; 
        span.style.cssText = `
            display: inline-block;
            white-space: nowrap;
            padding-left: 100%;
            will-change: transform;
            font-size: ${CONFIG.MARQUEE_FONT_SIZE};
            font-weight: 500;
        `;
    
        marquee.appendChild(span);
        document.body.appendChild(marquee);
    
        // 启动动画
        span.style.animation = `marquee ${scrollDuration}s linear forwards`;
    
        // --- 5. 清理 ---
        setTimeout(() => {
            if (marquee.parentNode) {
                span.style.animation = ''; 
                marquee.parentNode.removeChild(marquee);
            }
            state.isMarqueeActive = false;
        }, (scrollDuration * 1000) + 500);
    
        showKeyFeedback('节目信息开始滚动');
    }            
    function init() {
        addStyles();
        createDynamicUI();
        loadVolumeSettings();
        loadSettings(); // 从 storage 加载用户设置
        loadBlacklist(); // 加载黑名单
        parseInitialUrl();
        initGlobalEvents();
        addButtonHoverEffects();
        if (state.videoUrl) {
            UI.videoInfo.textContent = decodeURIComponent(state.videoUrl);
        }
        if (CONFIG.EPG_ENABLED) {
            loadEPG();
        }
    }
    function addStyles() {
        const style = document.createElement('style');
        style.textContent = `
            .switch-source-btn:hover {
                background: rgba(255, 255, 255, 0.2);
                border-radius: 3px;
                transform: scale(1);
                transition: all 0.2s ease;
            }
            .switch-source-btn:active {
                transform: scale(1);
                transition: all 0.1s ease;
            }
            /* info-panel 样式 */
            .info-panel {
                display: none;
                position: absolute;
                bottom: 60px;
                right: 10px;
                background: rgba(0, 0, 0, 0.85);
                padding: 12px;
                border-radius: 6px;
                font-size: 12px;
                line-height: 1.5;
                z-index: 20;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.5);
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255, 255, 255, 0.1);
            }
            .info-label {
                color: #4dabf7 !important;
                font-weight: normal;
            }
            .info-maohao {
                color: #20c997 !important;
            }
            .info-value {
                color: white !important;
            }
            .info-line {
                margin-bottom: 3px;
            }
            @keyframes fadeInOut {
                0% { opacity: 0; transform: translate(-50%, -10px); }
                15% { opacity: 1; transform: translate(-50%, 0); }
                85% { opacity: 1; transform: translate(-50%, 0); }
                100% { opacity: 0; transform: translate(-50%, -10px); }
            }
            .blacklist-error {
                background: linear-gradient(135deg, #ff6b6b, #c92a2a) !important;
                border: 2px solid #ff6b6b !important;
                color: white !important;
                font-weight: bold !important;
                padding: 15px !important;
                border-radius: 8px !important;
            }
            /* 新增：键盘反馈动画 */
            @keyframes keyFeedbackFlash {
                0% { transform: translateX(-50%) scale(0.9); opacity: 0; }
                15% { transform: translateX(-50%) scale(1.1); opacity: 1; }
                30% { transform: translateX(-50%) scale(1); opacity: 1; }
                85% { transform: translateX(-50%) scale(1); opacity: 1; }
                100% { transform: translateX(-50%) scale(0.9); opacity: 0; }
            }
            .key-feedback {
                animation: keyFeedbackFlash 1s ease;
            }
            /* 快捷键提示样式 */
            .shortcut-hint {
                position: absolute;
                top: 5px;
                right: 10px;
                background: rgba(0, 0, 0, 0.7);
                color: #aaa;
                padding: 6px 12px;
                border-radius: 6px;
                font-size: 11px;
                z-index: 10;
                cursor: help;
                transition: all 0.3s ease;
            }
            .shortcut-hint:hover {
                background: rgba(0, 0, 0, 0.9);
                color: white;
                transform: scale(1.05);
            }
            /* 快捷键提示更新 */
            .shortcut-hint table tr td:first-child b {
                color: #4dabf7;
            }
            /* 搜索框聚焦样式 */
            .playlist-search:focus {
                border-color: #4dabf7 !important;
                box-shadow: 0 0 0 3px rgba(77, 171, 247, 0.3) !important;
                outline: none !important;
            }
            /* 新增：搜索结果选中样式 */
            .playlist-item.selected {
                background: linear-gradient(180deg, #000000, #000000) !important;
                color: white !important;
                font-weight: bold !important;
                border-left: 4px solid #f59f00 !important;
                outline: 2px solid #37b24d;
                outline-offset: -2px;
            }
            .playlist-item.selected:hover {
                background: linear-gradient(135deg, #339af0, #1864ab) !important;
            }
            /* 播放列表焦点状态 */
            #playlist-container:focus-within {
                border-color: #4dabf7;
            }
            .playlist-item:focus {
                outline: 2px solid #4dabf7;
                outline-offset: -2px;
            }
            /* 音量极限状态提示 */
            @keyframes limitFlash {
                0% { transform: translateX(-50%) scale(1); }
                50% { transform: translateX(-50%) scale(1.1); background: rgba(255, 59, 48, 0.9); }
                100% { transform: translateX(-50%) scale(1); }
            }
            .volume-limit {
                animation: limitFlash 0.5s ease;
            }
            /* 新增：当前节目样式 */
            .current-program {
                display: block;
                font-size: 0.8em;
                color: #aaa;
                margin-top: 2px;
            }
            /* 新增：EPG弹出框样式 */
            .epg-popup {
                transition: all 0.2s ease;
				max-width: 300px;
                font-size: 12px;
                line-height: 1.4;
            }
            /* 新增：跑马灯动画 */
            @keyframes marquee {
                from { transform: translateX(0); }        /* 从右侧开始显示 */
                to   { transform: translateX(-100%); }    /* 滚到完全移出 */
            }
        `;
        document.head.appendChild(style);
    }
    function createDynamicUI() {
        UI.infoBtn = document.createElement("button");
        UI.infoBtn.className = "info-btn";
        UI.infoBtn.innerHTML = "ⓘ";
        UI.infoBtn.title = "播放信息(ｉ)";
        UI.infoBtn.style.cssText = "background:none; border:none; color:white; cursor:pointer; margin-left:10px;";
        UI.volumeContainer.insertAdjacentElement("afterend", UI.infoBtn);
        setupButtonHoverEffects(UI.infoBtn);
        UI.infoPanel = document.createElement("div");
        UI.infoPanel.className = "info-panel";
        UI.infoPanel.style.cssText = "display:none; position:absolute; bottom:60px; right:10px; background:rgba(0,0,0,0.8); padding:10px; border-radius:4px; font-size:12px; z-index: 20;";
        UI.videoContainer.appendChild(UI.infoPanel);
        UI.switchSourceBtn = document.createElement("button");
        UI.switchSourceBtn.className = "switch-source-btn";
        UI.switchSourceBtn.innerHTML = "⥮";
        UI.switchSourceBtn.title = "手动换源(ｓ)";
        UI.switchSourceBtn.style.cssText = "background:none; border:none; color:white; cursor:pointer; margin-left:10px; font-size:16px;";
        UI.infoBtn.insertAdjacentElement("afterend", UI.switchSourceBtn);
        setupButtonHoverEffects(UI.switchSourceBtn);
        // 新增：EPG按钮
        UI.epgBtn = document.createElement("button");
        UI.epgBtn.className = "epg-btn";
        UI.epgBtn.innerHTML = "📺";
        UI.epgBtn.title = "节目信息(e)";
        UI.epgBtn.style.cssText = "background:none; border:none; color:white; cursor:pointer; margin-left:10px;";
        UI.switchSourceBtn.insertAdjacentElement("afterend", UI.epgBtn);
        setupButtonHoverEffects(UI.epgBtn);
        UI.epgBtn.onclick = showEpgMarquee;
        // 添加快捷键提示
        const shortcutHint = document.createElement('div');
        shortcutHint.className = 'shortcut-hint';
        shortcutHint.innerHTML = '快捷键说明';
        shortcutHint.style.cssText = 'position:absolute; top:5px; right:10px; background:rgba(0,0,0,0.7); color:#aaa; padding:6px 12px; border-radius:6px; font-size:11px; z-index:10; cursor:help;';
        UI.videoContainer.appendChild(shortcutHint);
        // 鼠标悬停时显示完整快捷键列表
        shortcutHint.addEventListener('mouseenter', () => {
            shortcutHint.innerHTML = `
                <div style="font-weight:bold; margin-bottom:5px; border-bottom:1px solid #444; padding-bottom:3px;">快捷键列表</div>
                <table style="font-size:10px; line-height:1.6;">
                    <tr><td><b>/</b></td><td>搜索播放列表</td></tr>
                    <tr><td><b>Enter</b></td><td>播放选中频道</td></tr>
                    <tr><td><b>↑↓</b></td><td>在搜索结果中导航</td></tr>
                    <tr><td><b>空格</b></td><td>播放/暂停</td></tr>
                    <tr><td><b>↑↓</b></td><td>音量调节</td></tr>
                    <tr><td><b>←→</b></td><td>快退/快进5秒</td></tr>
                    <tr><td><b>f</b></td><td>全屏切换</td></tr>
                    <tr><td><b>m</b></td><td>静音切换</td></tr>
                    <tr><td><b>p</b></td><td>播放列表</td></tr>
                    <tr><td><b>ESC</b></td><td>关闭列表</td></tr>
                    <tr><td><b>[ ]</b></td><td>上/下一个频道</td></tr>
                    <tr><td><b>s</b></td><td>手动换源</td></tr>
                    <tr><td><b>i</b></td><td>信息面板</td></tr>
                    <tr><td><b>e</b></td><td>节目信息</td></tr>
                </table>
                <div style="margin-top:5px; font-size:9px; color:#aaa;">
                    提示：播放列表打开时，上下箭头用于导航
                </div>
            `;
            shortcutHint.style.width = '150px';
            shortcutHint.style.fontSize = '10px';
            shortcutHint.style.padding = '10px';
        });
        shortcutHint.addEventListener('mouseleave', () => {
            shortcutHint.innerHTML = '快捷键说明';
            shortcutHint.style.width = 'auto';
            shortcutHint.style.fontSize = '11px';
            shortcutHint.style.padding = '6px 12px';
        });
        // 给搜索框添加特殊类名以便CSS选择
        UI.playlistSearchInput.classList.add('playlist-search');
        // 给播放列表项目添加tabindex属性，使其可获得焦点
        UI.playlistItems.addEventListener('DOMNodeInserted', function() {
            const items = UI.playlistItems.querySelectorAll('.playlist-item');
            items.forEach((item, index) => {
                item.setAttribute('tabindex', '-1'); // 可通过脚本获取焦点，但不在Tab顺序中
            });
        });
    }
    // ==================== 修复的 togglePlaylistUI 函数 ====================
    function togglePlaylistUI(show) {
        const shouldShow = show !== undefined ? show : !UI.playlistContainer.classList.contains("hidden") === false;
        const currentlyVisible = !UI.playlistContainer.classList.contains("hidden");
        // 如果状态没有变化，直接返回
        if (shouldShow === currentlyVisible) return;
        UI.playlistContainer.classList.toggle("hidden", !shouldShow);
        if (shouldShow) {
            // 打开播放列表时，给播放列表容器添加一个焦点状态
            UI.playlistContainer.setAttribute('tabindex', '-1');
            UI.playlistContainer.classList.add('has-focus');
            // 如果有选中项，使其获得焦点
            setTimeout(() => {
                const selectedItem = UI.playlistItems.querySelector('.selected');
                if (selectedItem) {
                    selectedItem.focus();
                }
            }, 50);
            // 新增: 重新渲染以更新节目信息
            renderPlaylist(UI.playlistSearchInput.value);
        } else {
            // 如果关闭播放列表，确保移除焦点
            UI.playlistSearchInput.blur();
            UI.playlistSearchInput.style.border = "";
            UI.playlistSearchInput.style.boxShadow = "";
            // 清除选中项
            const selectedItem = UI.playlistItems.querySelector('.selected');
            if (selectedItem) {
                selectedItem.classList.remove('selected');
            }
        }
    }
    function loadVolumeSettings() {
        chrome.storage.local.get(["volume"], function(result) {
            if (result.volume !== undefined) {
                UI.videoPlayer.volume = result.volume;
                UI.volumeProgress.style.width = result.volume * 100 + "%";
                updateVolumeIcon();
            }
        });
    }
    function switchToPrevChannel() {
        if (!state.isM3UPlaylist || state.currentPlaylist.length === 0) {
            showNotification("当前不是播放列表模式或列表为空", 1500);
            return;
        }
        if (state.currentPlaylistIndex === -1) {
            state.currentPlaylistIndex = 0;
        }
        let prevIndex = state.currentPlaylistIndex - 1;
        if (prevIndex < 0) {
            prevIndex = state.currentPlaylist.length - 1;
        }
        console.log(`[频道切换] 切换到上一个频道: ${state.currentPlaylistIndex} → ${prevIndex}`);
        const item = state.currentPlaylist[prevIndex];
        if (item) {
            showNotification(`切换到上一个频道: ${item.title || `频道 ${prevIndex + 1}`}`, 1500);
        }
        playPlaylistItem(prevIndex);
    }
    function switchToNextChannel() {
        if (!state.isM3UPlaylist || state.currentPlaylist.length === 0) {
            showNotification("当前不是播放列表模式或列表为空", 1500);
            return;
        }
        if (state.currentPlaylistIndex === -1) {
            state.currentPlaylistIndex = 0;
        }
        let nextIndex = state.currentPlaylistIndex + 1;
        if (nextIndex >= state.currentPlaylist.length) {
            nextIndex = 0;
        }
        console.log(`[频道切换] 切换到下一个频道: ${state.currentPlaylistIndex} → ${nextIndex}`);
        const item = state.currentPlaylist[nextIndex];
        if (item) {
            showNotification(`切换到下一个频道: ${item.title || `频道 ${nextIndex + 1}`}`, 1500);
        }
        playPlaylistItem(nextIndex);
    }
    function parseInitialUrl() {
        const urlParams = new URLSearchParams(window.location.search);
        const queryUrl = urlParams.get("url");
        const hashUrl = window.location.hash.substring(1);
        state.videoUrl = queryUrl || hashUrl;
        if (state.videoUrl) {
            UI.videoInfo.textContent = decodeURIComponent(state.videoUrl);
            try {
                const urlObj = new URL(state.videoUrl);
                state.baseUrl = urlObj.href.substring(0, urlObj.href.lastIndexOf("/") + 1);
                state.originalPlaylistUrl = state.videoUrl;
            } catch (e) {
                console.warn("基础URL解析失败:", e);
                state.baseUrl = "";
                state.originalPlaylistUrl = state.videoUrl;
            }
        }
    }
    function clearTimers(keys = []) {
        const targets = keys.length > 0 ? keys : ["load", "stall"];
        targets.forEach(key => {
            if (state.timers[key]) {
                clearTimeout(state.timers[key]);
                state.timers[key] = null;
            }
        });
    }
    function showLoading(show) {
        UI.loading.style.display = show ? "block" : "none";
    }
    function showError(message) {
        showLoading(false);
        UI.errorMessage.textContent = message;
        UI.errorMessage.style.display = "block";
        if (message.includes("黑名单") || message.includes("拦截") || message.includes("禁止")) {
            UI.errorMessage.classList.add("blacklist-error");
        } else {
            UI.errorMessage.classList.remove("blacklist-error");
        }
    }
    function formatTime(seconds) {
        if (seconds === Infinity || isNaN(seconds)) return "Live";
        const m = Math.floor(seconds / 60);
        const s = Math.floor(seconds % 60);
        return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
    }
    function startVideoLoadProcess() {
        showLoading(true);
        UI.errorMessage.style.display = "none";
        UI.errorMessage.classList.remove("blacklist-error");
        checkAndInitPlayer(state.videoUrl);
    }
    // 新增：从 storage 加载用户设置
    function loadSettings() {
        chrome.storage.local.get([
            'loadTimeout',
            'stallTimeout',
            'maxRetryRounds',
            'searchDebounce',
            'playlistRefreshInterval',
            'autoRefreshEnabled',
            'epgEnabled',
            'epgUrl',
            'marqueeSpeed',
            'marqueeColor',
            'marqueeFontSize'
        ], function(result) {
            // 更新 CONFIG（将用户友好的单位转换为毫秒）
            if (result.loadTimeout !== undefined) {
                CONFIG.LOAD_TIMEOUT_MS = result.loadTimeout;
            }
            if (result.stallTimeout !== undefined) {
                CONFIG.STALL_TIMEOUT_MS = result.stallTimeout;
            }
            if (result.maxRetryRounds !== undefined) {
                CONFIG.MAX_RETRY_ROUNDS = result.maxRetryRounds;
            }
            if (result.searchDebounce !== undefined) {
                CONFIG.SEARCH_DEBOUNCE_MS = result.searchDebounce;
            }
            if (result.playlistRefreshInterval !== undefined) {
                CONFIG.PLAYLIST_REFRESH_INTERVAL = result.playlistRefreshInterval;
            }
            if (result.autoRefreshEnabled !== undefined) {
                CONFIG.AUTO_REFRESH_ENABLED = result.autoRefreshEnabled;
            }
            if (result.epgEnabled !== undefined) {
                CONFIG.EPG_ENABLED = result.epgEnabled;
            }
            if (result.epgUrl !== undefined) {
                CONFIG.EPG_URL = result.epgUrl;
            }
            if (result.marqueeSpeed !== undefined) {
                CONFIG.MARQUEE_SPEED = result.marqueeSpeed;
            }
            if (result.marqueeColor !== undefined) {
                CONFIG.MARQUEE_COLOR = result.marqueeColor;
            }
            if (result.marqueeFontSize !== undefined) {
                CONFIG.MARQUEE_FONT_SIZE = result.marqueeFontSize;
            }
            console.log('[设置] 配置已从 storage 加载');
            console.log('[设置] 加载超时:', CONFIG.LOAD_TIMEOUT_MS, 'ms');
            console.log('[设置] 卡顿超时:', CONFIG.STALL_TIMEOUT_MS, 'ms');
            console.log('[设置] 最大重试轮次:', CONFIG.MAX_RETRY_ROUNDS);
            console.log('[设置] 列表刷新间隔:', CONFIG.PLAYLIST_REFRESH_INTERVAL, 'ms');
            console.log('[设置] 自动刷新:', CONFIG.AUTO_REFRESH_ENABLED);
            console.log('[设置] EPG启用:', CONFIG.EPG_ENABLED);
            console.log('[设置] EPG URL:', CONFIG.EPG_URL);
            console.log('[设置] 跑马灯速度:', CONFIG.MARQUEE_SPEED, 's/char');
            console.log('[设置] 跑马灯颜色:', CONFIG.MARQUEE_COLOR);
            console.log('[设置] 跑马灯字体大小:', CONFIG.MARQUEE_FONT_SIZE);
            // 如果EPG启用，加载数据
            if (CONFIG.EPG_ENABLED) {
                loadEPG();
            }
        });
    }
    // 新增：监听设置更新消息
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.action === 'settingsUpdated') {
            console.log('[设置] 收到设置更新通知');
            // 更新 CONFIG
            if (message.config.loadTimeout) {
                CONFIG.LOAD_TIMEOUT_MS = message.config.loadTimeout;
                console.log('[设置] 更新加载超时:', CONFIG.LOAD_TIMEOUT_MS, 'ms');
            }
            if (message.config.stallTimeout) {
                CONFIG.STALL_TIMEOUT_MS = message.config.stallTimeout;
                console.log('[设置] 更新卡顿超时:', CONFIG.STALL_TIMEOUT_MS, 'ms');
            }
            if (message.config.maxRetryRounds) {
                CONFIG.MAX_RETRY_ROUNDS = message.config.maxRetryRounds;
                console.log('[设置] 更新最大重试轮次:', CONFIG.MAX_RETRY_ROUNDS);
            }
            if (message.config.searchDebounce) {
                CONFIG.SEARCH_DEBOUNCE_MS = message.config.searchDebounce;
                console.log('[设置] 更新搜索防抖:', CONFIG.SEARCH_DEBOUNCE_MS, 'ms');
            }
            if (message.config.playlistRefreshInterval) {
                CONFIG.PLAYLIST_REFRESH_INTERVAL = message.config.playlistRefreshInterval;
                console.log('[设置] 更新列表刷新间隔:', CONFIG.PLAYLIST_REFRESH_INTERVAL, 'ms');
                // 如果正在播放M3U列表，重启刷新定时器
                if (state.isM3UPlaylist && CONFIG.AUTO_REFRESH_ENABLED) {
                    if (state.timers.refreshPlaylist) {
                        clearTimeout(state.timers.refreshPlaylist);
                    }
                    startPlaylistRefreshTimer();
                }
            }
            if (message.config.autoRefreshEnabled !== undefined) {
                CONFIG.AUTO_REFRESH_ENABLED = message.config.autoRefreshEnabled;
                console.log('[设置] 更新自动刷新:', CONFIG.AUTO_REFRESH_ENABLED);
                if (!CONFIG.AUTO_REFRESH_ENABLED && state.timers.refreshPlaylist) {
                    clearTimeout(state.timers.refreshPlaylist);
                    state.timers.refreshPlaylist = null;
                } else if (CONFIG.AUTO_REFRESH_ENABLED && state.isM3UPlaylist) {
                    startPlaylistRefreshTimer();
                }
            }
            if (message.config.blacklist) {
                state.blacklist = message.config.blacklist;
                state.isBlacklistLoaded = true;
                console.log(`[设置] 黑名单已更新，${state.blacklist.length} 个关键词`);
            }
            // 在 chrome.runtime.onMessage 监听器中，修改 EPG 相关部分为：
            if (message.config.epgEnabled !== undefined) {
                const oldEnabled = CONFIG.EPG_ENABLED;
                CONFIG.EPG_ENABLED = message.config.epgEnabled;
                console.log('[设置] 更新EPG启用:', CONFIG.EPG_ENABLED);
                if (CONFIG.EPG_ENABLED !== oldEnabled) {  // 只在启用状态真正变化时才操作
                    if (CONFIG.EPG_ENABLED) {
                        loadEPG();  // 启用时才加载
                    } else {
                        state.epgData = {};
                        state.channelMap = {};
                        state.epgExpiryTime = 0;
                        if (state.timers.epgRefresh) {
                            clearTimeout(state.timers.epgRefresh);
                            state.timers.epgRefresh = null;
                        }
                    }
                }
            }
            if (message.config.epgUrl) {
                const oldUrl = CONFIG.EPG_URL;
                CONFIG.EPG_URL = message.config.epgUrl;
                console.log('[设置] 更新EPG URL:', CONFIG.EPG_URL);
                // URL 改变且 EPG 已启用时，才重新加载
                if (CONFIG.EPG_ENABLED && oldUrl !== CONFIG.EPG_URL) {
                    loadEPG();
                }
            }
            if (message.config.marqueeSpeed !== undefined) {
                CONFIG.MARQUEE_SPEED = message.config.marqueeSpeed;
                console.log('[设置] 更新跑马灯速度:', CONFIG.MARQUEE_SPEED, 's/char');
            }
            if (message.config.marqueeColor !== undefined) {
                CONFIG.MARQUEE_COLOR = message.config.marqueeColor;
                console.log('[设置] 更新跑马灯颜色:', CONFIG.MARQUEE_COLOR);
            }
            if (message.config.marqueeFontSize !== undefined) {
                CONFIG.MARQUEE_FONT_SIZE = message.config.marqueeFontSize;
                console.log('[设置] 更新跑马灯字体大小:', CONFIG.MARQUEE_FONT_SIZE);
            }
            // 更新信息面板
            updateInfoPanel();
            showNotification('设置已更新', 2000);
        }
    });
    // 修改后的 loadBlacklist 函数：优先从 storage，没有则从文件
    function loadBlacklist() {
        state.blacklist = [];
        state.isBlacklistLoaded = false;
        console.log('[黑名单] 开始加载黑名单...');
        // 1. 首先尝试从 storage 加载（用户自定义的）
        chrome.storage.local.get(['blacklist', 'blacklistContent'], function(result) {
            if (result.blacklist && Array.isArray(result.blacklist) && result.blacklist.length > 0) {
                // 从 storage 的数组加载成功
                state.blacklist = result.blacklist;
                console.log(`[黑名单] 从 storage 加载 ${state.blacklist.length} 个关键词`);
                state.isBlacklistLoaded = true;
                if (state.videoUrl) startVideoLoadProcess();
            } else if (result.blacklistContent) {
                // 从 storage 的字符串内容加载
                state.blacklist = result.blacklistContent.split('\n')
                    .map(line => line.trim())
                    .filter(line => line && !line.startsWith('#') && !line.startsWith('//'))
                    .filter(keyword => keyword.length > 0);
                console.log(`[黑名单] 从 storage 内容加载 ${state.blacklist.length} 个关键词`);
                state.isBlacklistLoaded = true;
                if (state.videoUrl) startVideoLoadProcess();
            } else {
                // 2. storage 中没有，则从文件加载
                console.log('[黑名单] storage 中无黑名单，尝试从文件加载');
                fetch(CONFIG.BLACKLIST_URL)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error(`HTTP ${response.status}`);
                        }
                        return response.text();
                    })
                    .then(text => {
                        state.blacklist = text.split('\n')
                            .map(line => line.trim())
                            .filter(line => line && !line.startsWith('#') && !line.startsWith('//'))
                            .filter(keyword => keyword.length > 0);
                        console.log(`[黑名单] 从文件加载 ${state.blacklist.length} 个关键词`);
                        state.isBlacklistLoaded = true;
                        if (state.videoUrl) startVideoLoadProcess();
                    })
                    .catch(error => {
                        console.warn('[黑名单] 文件加载失败，使用空黑名单:', error);
                        state.blacklist = [];
                        state.isBlacklistLoaded = true;
                        if (state.videoUrl) startVideoLoadProcess();
                    });
            }
        });
    }
    // 新增：为所有控制按钮添加统一的鼠标效果
    function addButtonHoverEffects() {
        const staticButtons = [
            UI.backBtn,
            UI.playPauseBtn,
            UI.prevChannelBtn,
            UI.nextChannelBtn,
            UI.volumeBtn,
            UI.fullscreenBtn,
            UI.playlistBtn,
            UI.closePlaylistBtn,
            UI.clearSearchBtn,
            UI.epgBtn // 新增
        ];
        staticButtons.forEach(button => {
            if (!button) return;
            setupButtonHoverEffects(button);
        });
    }
    function setupButtonHoverEffects(button) {
        if (!button) return;
        button.style.opacity = '1';
        button.style.transition = 'opacity 0.2s ease';
        button.addEventListener('mouseenter', () => {
            button.style.opacity = '0.8';
        });
        button.addEventListener('mouseleave', () => {
            button.style.opacity = '1';
        });
        button.addEventListener('mousedown', () => {
            button.style.opacity = '0.6';
        });
        button.addEventListener('mouseup', () => {
            button.style.opacity = '0.8';
        });
    }
    function checkUrlInBlacklist(url, urlType = "URL") {
        if (!url || typeof url !== 'string') {
            return false;
        }
        // 等待黑名单加载完成
        if (!state.isBlacklistLoaded) {
            console.log(`[黑名单] 等待黑名单加载完成...`);
            setTimeout(() => {
                checkUrlInBlacklist(url, urlType);
            }, 100);
            return false;
        }
        const lowerUrl = url.toLowerCase();
        for (const keyword of state.blacklist) {
            if (!keyword) continue;
            const lowerKeyword = keyword.toLowerCase();
            // 支持简单的通配符匹配
            if (lowerKeyword.includes('*')) {
                // 将通配符转换为正则表达式
                const pattern = lowerKeyword
                    .replace(/\./g, '\\.')
                    .replace(/\*/g, '.*');
                const regex = new RegExp(`^${pattern}$`);
                if (regex.test(lowerUrl)) {
                    console.warn(`[黑名单拦截] ${urlType} 匹配通配符模式: "${keyword}"`);
                    console.warn(`[黑名单拦截] 被拦截的URL: ${url}`);
                    showError(
                        `播放被拦截：链接匹配黑名单规则\n\n` +
                        `规则: ${keyword}\n` +
                        `URL: ${url.substring(0, 80)}${url.length > 80 ? '...' : ''}`
                    );
                    handleBlacklistedInPlaylist(url, keyword);
                    return true;
                }
            } else if (lowerUrl.includes(lowerKeyword)) {
                console.warn(`[黑名单拦截] ${urlType} 包含黑名单关键词: "${keyword}"`);
                console.warn(`[黑名单拦截] 被拦截的URL: ${url}`);
                showError(
                    `播放被拦截：链接包含黑名单关键词\n\n` +
                    `关键词: ${keyword}\n` +
                    `URL: ${url.substring(0, 80)}${url.length > 80 ? '...' : ''}`
                );
                handleBlacklistedInPlaylist(url, keyword);
                return true;
            }
        }
        return false;
    }
    // 新增：处理播放列表中被黑名单拦截的项目
    function handleBlacklistedInPlaylist(blockedUrl, keyword) {
        if (!state.isM3UPlaylist || state.currentPlaylistIndex === -1) {
            return;
        }
        const item = state.currentPlaylist[state.currentPlaylistIndex];
        if (!item) return;
        // 从当前频道的URL列表中移除被拦截的URL
        if (item.urls && item.urls.length > 0) {
            const originalLength = item.urls.length;
            item.urls = item.urls.filter(url => url !== blockedUrl);
            if (item.urls.length < originalLength) {
                console.warn(`[黑名单] 从频道 "${item.title}" 中移除 ${originalLength - item.urls.length} 个被拦截的源`);
                // 更新当前频道信息
                if (state.currentChannelInfo.urls) {
                    state.currentChannelInfo.urls = state.currentChannelInfo.urls.filter(url => url !== blockedUrl);
                }
                // 如果当前正在播放被拦截的源，切换到下一个源
                if (item.currentUrlIndex !== undefined &&
                    item.urls.length > 0 &&
                    item.currentUrlIndex >= item.urls.length) {
                    item.currentUrlIndex = 0;
                    showNotification(`源被黑名单拦截，自动切换`, 2000);
                    // 自动播放下一个源
                    const nextUrl = item.urls[0];
                    setTimeout(() => {
                        if (checkUrlInBlacklist(nextUrl, "下一个源")) {
                            return;
                        }
                        destroyPlayer();
                        showLoading(true);
                        UI.errorMessage.style.display = "none";
                        UI.videoInfo.textContent = item.title || decodeURIComponent(nextUrl);
                        checkAndInitPlayer(nextUrl);
                    }, 1500);
                }
            }
            // 如果频道所有源都被拦截，跳过这个频道
            if (item.urls.length === 0) {
                console.warn(`[黑名单] 频道 "${item.title}" 所有源均被拦截，将跳过`);
                showNotification(`频道 "${item.title}" 已被屏蔽`, 3000);
                // 自动播放下一个频道
                setTimeout(() => {
                    let nextIndex = state.currentPlaylistIndex + 1;
                    while (nextIndex < state.currentPlaylist.length) {
                        const nextItem = state.currentPlaylist[nextIndex];
                        if (nextItem && nextItem.urls && nextItem.urls.length > 0) {
                            // 检查下一个频道的第一个URL是否在黑名单中
                            const firstUrl = nextItem.urls[0];
                            if (!checkUrlInBlacklist(firstUrl, "下一个频道URL")) {
                                playPlaylistItem(nextIndex);
                                return;
                            }
                        }
                        nextIndex++;
                    }
                    // 所有频道都被屏蔽
                    showError("所有频道均被黑名单拦截，无法播放");
                }, 1500);
            }
        }
    }
    function checkAndInitPlayer(url) {
        const thisRequestId = ++state.loadRequestId;
        // 等待黑名单加载完成
        if (!state.isBlacklistLoaded) {
            console.log(`[Req #${thisRequestId}] 等待黑名单加载...`);
            setTimeout(() => {
                if (thisRequestId === state.loadRequestId) {
                    checkAndInitPlayer(url);
                }
            }, 100);
            return;
        }
        // 检查URL是否在黑名单中（包括原始URL）
        if (checkUrlInBlacklist(url, "原始URL")) {
            return;
        }
        const lowerUrl = url.toLowerCase();
        //if (/(?:\.(flv|m3u8|m3u)|#m3u8|#m3u)([?#].*)?$/.test(lowerUrl)) {
        if (/(?:#m3u8|#m3u)([?#].*)?$/.test(lowerUrl)) {
            if (thisRequestId === state.loadRequestId) {
                initPlayerWithUrl(url);
            }
        } else {
            console.log(`[Req #${thisRequestId}] 检测重定向及 Content-Type:`, url);
            new Promise(resolve => {
                chrome.runtime.sendMessage({
                    action: "checkRedirect",
                    url: url
                }, response => resolve(response));
            }).then(response => {
                if (thisRequestId !== state.loadRequestId) {
                    console.warn(`[Req #${thisRequestId}] 请求已过期 (当前ID: ${state.loadRequestId})，丢弃结果。`);
                    return;
                }
                if (response && response.success) {
                    console.log(`[Req #${thisRequestId}] 重定向成功: ${response.finalUrl}`);
                    // 检查重定向后的URL是否在黑名单中
                    if (checkUrlInBlacklist(response.finalUrl, "重定向URL")) {
                        return;
                    }
                    initPlayerWithUrl(response.finalUrl, response.contentType || "");
                } else {
                    console.warn(`[Req #${thisRequestId}] 重定向检测无响应或失败，尝试直连`);
                    initPlayerWithUrl(url);
                }
            });
        }
    }
    function destroyPlayer() {
        //console.log("销毁播放器，重置类型为未知");
        if (state.player) {
            if (typeof state.player.destroy === "function") {
                state.player.destroy();
            } else if (state.player instanceof Hls) {
                state.player.destroy();
            }
            state.player = null;
        }
        UI.videoPlayer.removeAttribute("src");
        UI.videoPlayer.load();
        state.isPlaying = false;
        clearTimers();
        state.streamInfo = {
            resolution: "未知",
            type: "未知"
        };
    }
    function initPlayerWithUrl(url, contentType = "") {
        // 再次检查URL（以防万一）
        if (checkUrlInBlacklist(url, "播放URL")) {
            return;
        }
        const lowerUrl = url.toLowerCase();
        const ct = contentType.toLowerCase();
        const isHlsContent = ct.includes("mpegurl") || ct.includes("hls") || ct.includes("text/html") || ct.includes("text/plain") || ct.includes("application/octet-stream");
        if (/(?:[.]m3u|#m3u)([?#].*)?$/.test(lowerUrl)) {
            //state.streamInfo.type = "M3U";
            //console.log("设置播放器类型:", state.streamInfo.type);
            initM3UPlaylist(url);
        } else if (isHlsContent || /(?:[.]m3u8|#m3u8)([?#].*)?$/.test(lowerUrl)) {
            //state.streamInfo.type = isHlsContent ? "HLS (Type)" : "HLS";
            //console.log("设置播放器类型:", state.streamInfo.type);
            initHlsPlayer(url);
        } else if (/\.flv([?#].*)?$/.test(lowerUrl)) {
            //state.streamInfo.type = "FLV";
            //console.log("设置播放器类型:", state.streamInfo.type);
            initFlvPlayer(url);
        } else {
            //state.streamInfo.type = "原生";
            //console.log("设置播放器类型:", state.streamInfo.type);
            initNativePlayer(url);
        }
    }
    function initFlvPlayer(url) {
        if (!flvjs.isSupported()) {
            return handleError("您的浏览器不支持FLV播放");
        }
        destroyPlayer();
        state.streamInfo.type = "FLV";
        const player = flvjs.createPlayer({
            type: "flv",
            url: url
        });
        player.attachMediaElement(UI.videoPlayer);
        player.load();
        player.on(flvjs.Events.METADATA_ARRIVED, metadata => {
            clearTimers(["load"]);
            if (metadata?.onMetaData) {
                const { width, height } = metadata.onMetaData;
                if (width && height) state.streamInfo.resolution = `${width}x${height}`;
                updateInfoPanel();
            }
        });
        player.on(flvjs.Events.ERROR, (type, detail) => {
            console.error("FLV Error:", type, detail);
            handleError(`FLV播放错误: ${type}`);
        });
        state.player = player;
        attachCommonVideoEvents();
    }
    function initHlsPlayer(url) {
        if (Hls.isSupported()) {
            destroyPlayer();
            state.streamInfo.type = "HLS";
            const player = new Hls({
                debug: false,
                capLevelToPlayerSize: true,
                autoLevelEnabled: true,
                fragLoadingMaxRetry: 1,
                fragLoadingRetryDelay: 500
            });
            player.loadSource(url);
            player.attachMedia(UI.videoPlayer);
            player.on(Hls.Events.MANIFEST_PARSED, (event, data) => {
                clearTimers(["load"]);
                console.log("HLS Manifest Parsed");
                showLoading(false);
                updateResolutionFromHls(player, data);
                attemptPlay();
            });
            player.on(Hls.Events.ERROR, (event, data) => {
                if (data.fatal) {
                    console.error("HLS Fatal Error:", data.type, data.details);
                    handleError(`HLS播放错误: ${data.details}`);
                }
            });
            state.player = player;
            attachCommonVideoEvents();
        } else if (UI.videoPlayer.canPlayType("application/vnd.apple.mpegurl")) {
            destroyPlayer();
            UI.videoPlayer.src = url;
            attachCommonVideoEvents();
        } else {
            handleError("您的浏览器不支持HLS播放");
        }
    }
    function initNativePlayer(url) {
        destroyPlayer();
        state.streamInfo.type = "原生";
        const lower = url.toLowerCase();
        if (lower.includes(".mp4")) state.streamInfo.type = "MP4";
        else if (lower.includes(".webm")) state.streamInfo.type = "WebM";
        else if (lower.includes(".ogg") || lower.includes(".ogv")) state.streamInfo.type = "OGG";
        UI.videoPlayer.src = url;
        attachCommonVideoEvents();
    }
    function attachCommonVideoEvents() {
        UI.videoPlayer.onloadedmetadata = function() {
            clearTimers(["load"]);
            showLoading(false);
            updateVideoInfoFromElement();
            attemptPlay();
        };
        UI.videoPlayer.onloadeddata = function() {
            updateVideoInfoFromElement();
        };
        UI.videoPlayer.onerror = function() {
            if (!UI.videoPlayer.getAttribute("src") && !UI.videoPlayer.currentSrc) return;
            handleError("视频加载失败或格式不支持");
        };
        UI.videoPlayer.onplay = () => {
            state.isPlaying = true;
            UI.playPauseBtn.textContent = "❚❚";
            UI.playPauseBtn.title = "暂停(空格键)";
        };
        UI.videoPlayer.onpause = () => {
            state.isPlaying = false;
            UI.playPauseBtn.textContent = "▶";
            UI.playPauseBtn.title = "播放(空格键)";
        };
        UI.videoPlayer.ontimeupdate = updateProgress;
        UI.videoPlayer.onvolumechange = updateVolumeIcon;
        UI.videoPlayer.onended = () => {
            if (state.isM3UPlaylist) {
                const item = state.currentPlaylist[state.currentPlaylistIndex];
                if (item && item.urls && item.currentUrlIndex < item.urls.length - 1) {
                    item.currentUrlIndex++;
                    console.log(`当前源播放结束，切换至本频道下一个源: ${item.currentUrlIndex + 1}/${item.urls.length}`);
                    showNotification(`播放结束，切换到源 ${item.currentUrlIndex + 1}/${item.urls.length}`, 1500);
                    const nextUrl = item.urls[item.currentUrlIndex];
                    destroyPlayer();
                    showLoading(true);
                    UI.errorMessage.style.display = "none";
                    UI.videoInfo.textContent = item.title || decodeURIComponent(nextUrl);
                    checkAndInitPlayer(nextUrl);
                    if (state.timers.load) clearTimeout(state.timers.load);
                    state.timers.load = setTimeout(() => {
                        console.error(`加载超时 (${CONFIG.LOAD_TIMEOUT_MS}ms)，切换线路。`);
                        tryNextRedundantUrl();
                    }, CONFIG.LOAD_TIMEOUT_MS);
                    return;
                }
                if (state.currentPlaylistIndex < state.currentPlaylist.length - 1) {
                    playPlaylistItem(state.currentPlaylistIndex + 1);
                }
            }
        };
        UI.videoPlayer.onwaiting = () => {
            if (state.isM3UPlaylist && state.isPlaying) {
                console.warn(`卡顿检测: 启动超时计时器 (${CONFIG.STALL_TIMEOUT_MS}ms)`);
                if (state.timers.stall) clearTimeout(state.timers.stall);
                state.timers.stall = setTimeout(() => {
                    console.error("播放停滞超时，尝试切换线路。");
                    showNotification("卡顿超时，自动换源", 1500);
                    tryNextRedundantUrl();
                }, CONFIG.STALL_TIMEOUT_MS);
            }
        };
        UI.videoPlayer.onplaying = () => {
            if (state.timers.stall) {
                clearTimeout(state.timers.stall);
                state.timers.stall = null;
            }
        };
    }
    function handleError(msg) {
        if (state.isM3UPlaylist) {
            console.warn(`捕获错误: ${msg} -> 尝试下一个源`);
            tryNextRedundantUrl();
        } else {
            showError(msg);
        }
    }
    let isFirstPlay = true;
    function attemptPlay() {
        const promise = UI.videoPlayer.play();
        if (promise !== undefined) {
            promise.then(() => {
                state.isPlaying = true;
                UI.playPauseBtn.textContent = "❚❚";
                UI.playPauseBtn.title = "暂停(空格键)";
                if (isFirstPlay && !document.fullscreenElement) {
                    isFirstPlay = false;
                }
            }).catch(error => {
                console.error("自动播放被阻止或失败:", error);
                state.isPlaying = false;
                UI.playPauseBtn.textContent = "▶";
                UI.playPauseBtn.title = "播放(空格键)";
            });
        }
    }
    function initM3UPlaylist(url) {
        state.isM3UPlaylist = true;
        state.streamInfo.type = "M3U";
        const parser = new M3UParser;
        parser.parseFromUrl(url).then(playlist => {
            if (!playlist || playlist.length === 0) {
                throw new Error("播放列表为空");
            }
            const processedPlaylist = playlist.map(item => {
                // 假设parser已解析tvg-id，如果没有，这里添加
                if (!item.tvgId && item.attributes) {
                    item.tvgId = item.attributes['tvg-id'];
                }
                const rawUrls = item.urls && item.urls.length > 0 ? item.urls : [item.url];
                const validUrls = rawUrls.filter(u => u).map(u => {
                    if (!u.startsWith("http") && !u.startsWith("//")) {
                        return M3UParser.resolveUrl(state.baseUrl, u);
                    }
                    return u;
                });
                item.urls = validUrls;
                return item;
            }).filter(item => item.urls.length > 0);
            if (processedPlaylist.length === 0) {
                throw new Error("解析后无有效项目");
            }
            if (state.currentPlaylist.length === 0) {
                state.currentPlaylist = processedPlaylist;
                renderPlaylist();
                playPlaylistItem(0);
                togglePlaylistUI(true);
                if (CONFIG.AUTO_REFRESH_ENABLED) {
                    startPlaylistRefreshTimer();
                }
            } else {
                refreshPlaylist(processedPlaylist);
            }
        }).catch(err => {
            console.error("M3U解析失败:", err);
            showError("解析播放列表失败: " + err.message);
        });
    }
    function startPlaylistRefreshTimer() {
        if (state.timers.refreshPlaylist) {
            clearTimeout(state.timers.refreshPlaylist);
            state.timers.refreshPlaylist = null;
        }
        if (!CONFIG.AUTO_REFRESH_ENABLED) {
            console.log('[定时刷新] 自动刷新已禁用');
            return;
        }
        if (CONFIG.PLAYLIST_REFRESH_INTERVAL <= 0) {
            console.log('[定时刷新] 刷新间隔为0，不启用定时刷新');
            return;
        }
        state.timers.refreshPlaylist = setTimeout(() => {
            console.log(`[定时刷新] 开始刷新播放列表...`);
            refreshM3UPlaylist();
        }, CONFIG.PLAYLIST_REFRESH_INTERVAL);
        console.log(`[定时刷新] 已设置定时器，${Math.round(CONFIG.PLAYLIST_REFRESH_INTERVAL/1000)}秒后刷新`);
    }
    function refreshM3UPlaylist() {
        if (!state.isM3UPlaylist || !state.originalPlaylistUrl) {
            console.warn("[定时刷新] 当前不是M3U播放列表或缺少原始URL");
            startPlaylistRefreshTimer();
            return;
        }
        console.log(`[定时刷新] 刷新播放列表: ${state.originalPlaylistUrl}`);
        const parser = new M3UParser;
        parser.parseFromUrl(state.originalPlaylistUrl).then(playlist => {
            if (!playlist || playlist.length === 0) {
                console.warn("[定时刷新] 刷新的播放列表为空");
                startPlaylistRefreshTimer();
                return;
            }
            const processedPlaylist = playlist.map(item => {
                const rawUrls = item.urls && item.urls.length > 0 ? item.urls : [item.url];
                const validUrls = rawUrls.filter(u => u).map(u => {
                    if (!u.startsWith("http") && !u.startsWith("//")) {
                        return M3UParser.resolveUrl(state.baseUrl, u);
                    }
                    return u;
                });
                item.urls = validUrls;
                return item;
            }).filter(item => item.urls.length > 0);
            if (processedPlaylist.length === 0) {
                console.warn("[定时刷新] 解析后无有效项目");
                startPlaylistRefreshTimer();
                return;
            }
            refreshPlaylist(processedPlaylist);
            startPlaylistRefreshTimer();
        }).catch(err => {
            console.error("[定时刷新] M3U解析失败:", err);
            startPlaylistRefreshTimer();
        });
    }
    function refreshPlaylist(newPlaylist) {
        console.log('[定时刷新] 开始刷新播放列表...');
        const oldIndex = state.currentPlaylistIndex;
        const oldItem = oldIndex >= 0 ? state.currentPlaylist[oldIndex] : null;
        if (oldItem) {
            state.currentChannelInfo = {
                title: oldItem.title || "",
                originalIndex: oldIndex,
                urls: [...oldItem.urls],
                currentUrlIndex: oldItem.currentUrlIndex || 0,
                currentRound: oldItem.currentRound || 1
            };
            console.log(`[定时刷新] 保存当前频道: "${state.currentChannelInfo.title}"`);
        }
        const oldPlaylist = [...state.currentPlaylist];
        state.currentPlaylist = newPlaylist;
        let newIndex = -1;
        if (state.currentChannelInfo.title) {
            newIndex = state.currentPlaylist.findIndex(item =>
                item.title === state.currentChannelInfo.title
            );
            if (newIndex === -1 && state.currentChannelInfo.urls.length > 0) {
                newIndex = state.currentPlaylist.findIndex(item =>
                    item.urls && item.urls.some(url =>
                        state.currentChannelInfo.urls.includes(url)
                    )
                );
            }
        }
        if (newIndex === -1) {
            console.log(`[定时刷新] 当前频道在新列表中不存在，继续播放原频道`);
            if (oldItem) {
                const preservedItem = {
                    ...oldItem,
                    title: oldItem.title ? `${oldItem.title} (旧列表)` : "旧列表频道"
                };
                state.currentPlaylist.push(preservedItem);
                newIndex = state.currentPlaylist.length - 1;
                state.currentPlaylistIndex = newIndex;
            }
        } else {
            console.log(`[定时刷新] 在新列表中找到当前频道，位置: ${newIndex}`);
            state.currentPlaylistIndex = newIndex;
            const newItem = state.currentPlaylist[newIndex];
            if (newItem.urls && newItem.urls.length > 0) {
                newItem.currentUrlIndex = oldItem ? oldItem.currentUrlIndex || 0 : 0;
                newItem.currentRound = oldItem ? oldItem.currentRound || 1 : 1;
            }
        }
        renderPlaylist(UI.playlistSearchInput.value);
        updatePlaylistHighlight();
        if (!UI.playlistContainer.classList.contains("hidden")) {
            const currentSearch = UI.playlistSearchInput.value;
            if (currentSearch) {
                renderPlaylist(currentSearch);
            }
            addRefreshIndicator();
        }
        showRefreshNotification(`播放列表已刷新: ${oldPlaylist.length} → ${newPlaylist.length} 个频道`);
        console.log(`[定时刷新] 播放列表刷新完成: ${oldPlaylist.length} → ${newPlaylist.length} 个频道`);
    }
    function addRefreshIndicator() {
        const oldIndicator = UI.playlistContainer.querySelector('.refresh-indicator');
        if (oldIndicator) {
            oldIndicator.remove();
        }
        const indicator = document.createElement('div');
        indicator.className = 'refresh-indicator';
        indicator.textContent = '刷新中...';
        indicator.style.cssText = `
            position: absolute;
            top: 10px;
            right: 10px;
            background: rgba(0, 100, 0, 0.8);
            color: white;
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 12px;
            z-index: 1002;
        `;
        UI.playlistContainer.appendChild(indicator);
        setTimeout(() => {
            if (indicator.parentNode) {
                indicator.parentNode.removeChild(indicator);
            }
        }, 1500);
    }
    function showRefreshNotification(message) {
        const oldNotifications = document.querySelectorAll('.refresh-notification');
        oldNotifications.forEach(n => n.remove());
        const notification = document.createElement("div");
        notification.className = "refresh-notification";
        notification.textContent = message;
        if (!document.querySelector('#refresh-notification-style')) {
            const style = document.createElement('style');
            style.id = 'refresh-notification-style';
            style.textContent = `
                @keyframes fadeInOut {
                    0% { opacity: 0; transform: translateY(-10px); }
                    10% { opacity: 1; transform: translateY(0); }
                    90% { opacity: 1; transform: translateY(0); }
                    100% { opacity: 0; transform: translateY(-10px); }
                }
                .refresh-notification {
                    pointer-events: none;
                }
            `;
            document.head.appendChild(style);
        }
        document.body.appendChild(notification);
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 3000);
    }
    function manualSwitchToNextSource() {
        if (state.currentPlaylistIndex === -1) return;
        const item = state.currentPlaylist[state.currentPlaylistIndex];
        if (!item || !item.urls || item.urls.length === 0) {
            showError("当前频道没有可用的源");
            return;
        }
        if (item.urls.length <= 1) {
            showNotification("当前频道只有一个源", 1500);
            return;
        }
        if (item.currentUrlIndex === undefined) item.currentUrlIndex = 0;
        if (item.currentRound === undefined) item.currentRound = 1;
        const nextIndex = (item.currentUrlIndex + 1) % item.urls.length;
        if (nextIndex === 0) {
            if (item.currentRound < CONFIG.MAX_RETRY_ROUNDS) {
                item.currentRound++;
            }
        }
        console.log(`[手动换源] 从源 ${item.currentUrlIndex + 1} 切换到源 ${nextIndex + 1} (轮次: ${item.currentRound}/${CONFIG.MAX_RETRY_ROUNDS})`);
        item.currentUrlIndex = nextIndex;
        const nextUrl = item.urls[nextIndex];
        // 检查黑名单
        if (checkUrlInBlacklist(nextUrl, "手动换源URL")) {
            // 如果被拦截，继续尝试下一个
            setTimeout(() => manualSwitchToNextSource(), 500);
            return;
        }
        showLoading(true);
        UI.errorMessage.style.display = "none";
        showNotification(`切换到源 ${nextIndex + 1}/${item.urls.length}`, 2000);
        destroyPlayer();
        checkAndInitPlayer(nextUrl);
        if (state.timers.load) clearTimeout(state.timers.load);
        state.timers.load = setTimeout(() => {
            console.error(`[手动换源] 加载超时 (${CONFIG.LOAD_TIMEOUT_MS}ms)，触发自动换源逻辑。`);
            tryNextRedundantUrl();
        }, CONFIG.LOAD_TIMEOUT_MS);
        setTimeout(updateInfoPanel, 500);
    }
    function showNotification(message, duration = 2000) {
        const oldNotification = document.querySelector('.source-notification');
        if (oldNotification) {
            oldNotification.remove();
        }
        const notification = document.createElement("div");
        notification.className = "source-notification";
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(0, 100, 200, 0.9);
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            z-index: 1000;
            font-size: 14px;
            animation: fadeInOut ${duration/1000}s ease-in-out;
        `;
        document.body.appendChild(notification);
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, duration);
    }
    function tryNextRedundantUrl() {
        if (state.currentPlaylistIndex === -1) return;
        const item = state.currentPlaylist[state.currentPlaylistIndex];
        if (!item || !item.urls || item.urls.length === 0) {
            showError("播放列表数据错误");
            return;
        }
        if (item.currentRound === undefined) item.currentRound = 1;
        if (item.currentUrlIndex === undefined) item.currentUrlIndex = 0;
        const nextIndex = item.currentUrlIndex + 1;
        if (nextIndex < item.urls.length) {
            item.currentUrlIndex = nextIndex;
        } else if (item.currentRound < CONFIG.MAX_RETRY_ROUNDS) {
            item.currentUrlIndex = 0;
            item.currentRound++;
            console.warn(`频道 [${item.title}] 开启第 ${item.currentRound}/${CONFIG.MAX_RETRY_ROUNDS} 轮尝试...`);
            showNotification(`第 ${item.currentRound} 轮尝试 (共 ${CONFIG.MAX_RETRY_ROUNDS} 轮)`, 2000);
        } else {
            if (state.timers.load) {
                clearTimeout(state.timers.load);
                state.timers.load = null;
            }
            destroyPlayer();
            state.isPlaying = false;
            UI.playPauseBtn.textContent = "▶";
            UI.playPauseBtn.title = "播放";
            showError(`频道 [${item.title || "未知"}] 无法播放或太过卡顿，请尝试其他频道。`);
            return;
        }
        const nextUrl = item.urls[item.currentUrlIndex];
        // 检查黑名单
        if (checkUrlInBlacklist(nextUrl, "自动换源URL")) {
            // 如果被拦截，继续尝试下一个
            setTimeout(() => tryNextRedundantUrl(), 500);
            return;
        }
        console.warn(`自动换源 (轮次:${item.currentRound}, 索引:${item.currentUrlIndex}): ${nextUrl}`);
        showNotification(`自动切换到源 ${item.currentUrlIndex + 1}/${item.urls.length}`, 1500);
        destroyPlayer();
        showLoading(true);
        UI.errorMessage.style.display = "none";
        checkAndInitPlayer(nextUrl);
        state.timers.load = setTimeout(() => {
            console.error(`加载超时 (${CONFIG.LOAD_TIMEOUT_MS}ms)，切换线路。`);
            tryNextRedundantUrl();
        }, CONFIG.LOAD_TIMEOUT_MS);
    }
    function playPlaylistItem(index) {
        if (index < 0 || index >= state.currentPlaylist.length) return;
        const item = state.currentPlaylist[index];
        const itemUrl = item.urls[0];
        // 检查URL是否在黑名单中
        if (checkUrlInBlacklist(itemUrl, "播放列表URL")) {
            return;
        }
        state.currentPlaylistIndex = index;
        item.currentUrlIndex = 0;
        item.currentRound = 1;
        state.currentChannelInfo = {
            title: item.title || "",
            originalIndex: index,
            urls: [...item.urls]
        };
        updatePlaylistHighlight();
        UI.videoInfo.textContent = item.title || decodeURIComponent(itemUrl);
        destroyPlayer();
        showLoading(true);
        UI.errorMessage.style.display = "none";
        checkAndInitPlayer(itemUrl);
        state.timers.load = setTimeout(() => {
            console.error(`加载超时 (${CONFIG.LOAD_TIMEOUT_MS}ms)，切换线路。`);
            tryNextRedundantUrl();
        }, CONFIG.LOAD_TIMEOUT_MS);
    }
    function renderPlaylist(searchTerm = "") {
        UI.playlistItems.innerHTML = "";
        const lowerTerm = searchTerm.toLowerCase();
        const fragment = document.createDocumentFragment();
        state.currentPlaylist.forEach((item, index) => {
            const channelName = item.title || `项目 ${index + 1}`;
            if (searchTerm && !channelName.toLowerCase().includes(lowerTerm)) {
                return;
            }
            const el = document.createElement("div");
            el.className = "playlist-item";
            if (index === state.currentPlaylistIndex) el.classList.add("active");
            el.textContent = channelName;
            el.dataset.index = index;
            el.onclick = () => {
                playPlaylistItem(index);
                // 点击后保持播放列表焦点状态
                maintainPlaylistFocus();
            };
            setupButtonHoverEffects(el);
            // 添加鼠标和焦点事件以显示EPG弹出框
            el.addEventListener('mouseenter', () => showEpgPopup(el, item));
            el.addEventListener('mouseleave', hideEpgPopup);
            el.addEventListener('focus', () => showEpgPopup(el, item));
            el.addEventListener('blur', hideEpgPopup);
            // 如果EPG启用，添加当前节目显示
            if (CONFIG.EPG_ENABLED) {
                const chId = getChannelId(item);
                const programs = state.epgData[chId] || [];
                const current = getCurrentProgram(programs);
                if (current) {
                    const span = document.createElement('span');
                    span.className = 'current-program';
                    span.textContent = `当前: ${current.title}`;
                    el.appendChild(span);
                }
            }
            fragment.appendChild(el);
        });
        UI.playlistItems.appendChild(fragment);
    }
    function updatePlaylistHighlight() {
        const items = UI.playlistItems.children;
        for (let el of items) {
            if (parseInt(el.dataset.index) === state.currentPlaylistIndex) {
                el.classList.add("active");
                el.scrollIntoView({
                    behavior: "smooth",
                    block: "nearest"
                });
            } else {
                el.classList.remove("active");
            }
        }
    }
    function handlePlaylistSearch(e) {
        const term = e.target.value;
        if (term) UI.clearSearchBtn.classList.add("visible");
        else UI.clearSearchBtn.classList.remove("visible");
        if (state.timers.searchDebounce) clearTimeout(state.timers.searchDebounce);
        state.timers.searchDebounce = setTimeout(() => {
            renderPlaylist(term);
            // 搜索后清除选中项
            const selectedItem = UI.playlistItems.querySelector('.selected');
            if (selectedItem) {
                selectedItem.classList.remove('selected');
            }
        }, CONFIG.SEARCH_DEBOUNCE_MS);
    }
    function clearSearch() {
        UI.playlistSearchInput.value = "";
        UI.clearSearchBtn.classList.remove("visible");
        renderPlaylist("");
        // 清除选中项
        const selectedItem = UI.playlistItems.querySelector('.selected');
        if (selectedItem) {
            selectedItem.classList.remove('selected');
        }
    }
    function updateVideoInfoFromElement() {
        if (UI.videoPlayer.videoWidth && UI.videoPlayer.videoHeight) {
            state.streamInfo.resolution = `${UI.videoPlayer.videoWidth}x${UI.videoPlayer.videoHeight}`;
        }
        updateInfoPanel();
    }
    function updateResolutionFromHls(hlsPlayer, data) {
        if (data && data.levels && data.levels.length > 0) {
            const currentLevel = hlsPlayer.currentLevel >= 0 ? hlsPlayer.currentLevel : hlsPlayer.autoLevelEnabled ? hlsPlayer.autoLevelLast : 0;
            const levelData = data.levels[currentLevel];
            if (levelData && levelData.width) {
                state.streamInfo.resolution = `${levelData.width}x${levelData.height}`;
            }
        }
        updateInfoPanel();
    }
    function updateInfoPanel() {
        const lines = [
            `类型: ${state.streamInfo.type}`,
            `分辨率: ${state.streamInfo.resolution}`
        ];
        if (state.isM3UPlaylist && state.currentPlaylistIndex >= 0) {
            const item = state.currentPlaylist[state.currentPlaylistIndex];
            if (item) {
                const totalUrls = item.urls ? item.urls.length : 0;
                const currentIndex = (item.currentUrlIndex || 0) + 1;
                const round = item.currentRound || 1;
                lines.push(`频道列表: ${state.currentPlaylistIndex + 1}/${state.currentPlaylist.length}`);
                //lines.push(`加载超时: ${Math.round(CONFIG.LOAD_TIMEOUT_MS/1000)}秒`);
                //lines.push(`卡顿超时: ${Math.round(CONFIG.STALL_TIMEOUT_MS/1000)}秒`);
                //lines.push(`最大重试: ${CONFIG.MAX_RETRY_ROUNDS}轮`);
                if (totalUrls > 1) {
                    lines.push(`源: ${currentIndex}/${totalUrls}`);
                    lines.push(`轮次: ${round}/${CONFIG.MAX_RETRY_ROUNDS}`);
                }
                if (CONFIG.AUTO_REFRESH_ENABLED && state.timers.refreshPlaylist) {
                    lines.push(`列表刷新: ${Math.round(CONFIG.PLAYLIST_REFRESH_INTERVAL/60000)}分钟`);
                }
                if (item.title && item.title.includes("(旧列表)")) {
                    lines.push(`状态: 来自旧列表`);
                }
            }
        }
        // 添加黑名单信息
        if (state.blacklist.length > 0) {
            lines.push(`黑名单: ${state.blacklist.length}个规则`);
        }
        // 创建带颜色分类的HTML内容
        const coloredLines = lines.map(line => {
            if (line.includes(':')) {
                const parts = line.split(':');
                const label = parts[0];
                const value = parts.slice(1).join(':').trim();
                return `<div class="info-line"><span class="info-label">${label}</span> <span class="info-maohao">:</span> <span class="info-value">${value}</span></div>`;
            }
            return `<div class="info-line"><span class="info-label">${line}</span></div>`;
        });
        UI.infoPanel.innerHTML = coloredLines.join('');
    }
    function toggleVideoInfo() {
        updateInfoPanel();
        const currentDisplay = UI.infoPanel.style.display;
        UI.infoPanel.style.display = currentDisplay === "none" ? "block" : "none";
    }
    function updateProgress() {
        const { currentTime, duration } = UI.videoPlayer;
        if (duration && !isNaN(duration) && duration !== Infinity) {
            const percent = currentTime / duration * 100;
            UI.progressBar.style.width = percent + "%";
            UI.timeDisplay.textContent = `${formatTime(currentTime)} / ${formatTime(duration)}`;
        } else {
            UI.progressBar.style.width = "100%";
            UI.timeDisplay.textContent = `${formatTime(currentTime)} / Live`;
        }
    }
    function seek(e) {
        if (!UI.videoPlayer.duration || UI.videoPlayer.duration === Infinity) return;
        const rect = UI.progress.getBoundingClientRect();
        const pos = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        UI.videoPlayer.currentTime = pos * UI.videoPlayer.duration;
    }
    function adjustVolume(e) {
        const rect = UI.volumeSlider.getBoundingClientRect();
        let volume = (e.clientX - rect.left) / rect.width;
        volume = Math.max(0, Math.min(1, volume));
        UI.videoPlayer.volume = volume;
        UI.volumeProgress.style.width = volume * 100 + "%";
        updateVolumeIcon();
        chrome.storage.local.set({
            volume: volume
        });
    }
    function updateVolumeIcon() {
        const v = UI.videoPlayer.volume;
        if (UI.videoPlayer.muted || v === 0) UI.volumeBtn.textContent = "🔇";
        else if (v < .5) UI.volumeBtn.textContent = "🔉";
        else UI.volumeBtn.textContent = "🔊";
    }
    function toggleMute() {
        UI.videoPlayer.muted = !UI.videoPlayer.muted;
        updateVolumeIcon();
    }
    function toggleFullscreen() {
        const container = document.querySelector(".player-container");
        if (!document.fullscreenElement) {
            (container.requestFullscreen || container.webkitRequestFullscreen || container.msRequestFullscreen).call(container);
        } else {
            (document.exitFullscreen || document.webkitExitFullscreen || document.msExitFullscreen).call(document);
        }
    }
    function togglePlayPause() {
        if (UI.videoPlayer.paused) attemptPlay();
        else UI.videoPlayer.pause();
    }
    function showControls() {
        UI.controls.classList.remove("hidden");
        if (state.timers.controls) clearTimeout(state.timers.controls);
        state.timers.controls = setTimeout(() => {
            if (state.isPlaying) {
                UI.controls.classList.add("hidden");
            }
        }, 30000);
    }
    function initGlobalEvents() {
        document.addEventListener("mousemove", showControls);
        // 添加键盘事件监听
        document.addEventListener("keydown", handleKeyDown);
        UI.playPauseBtn.onclick = togglePlayPause;
        UI.prevChannelBtn.onclick = function(e) {
            e.stopPropagation();
            switchToPrevChannel();
        };
        UI.nextChannelBtn.onclick = function(e) {
            e.stopPropagation();
            switchToNextChannel();
        };
        UI.volumeBtn.onclick = toggleMute;
        UI.volumeSlider.onclick = adjustVolume;
        UI.fullscreenBtn.onclick = toggleFullscreen;
        UI.backBtn.onclick = () => window.close();
        UI.infoBtn.onclick = toggleVideoInfo;
        UI.playlistBtn.onclick = () => togglePlaylistUI();
        UI.closePlaylistBtn.onclick = () => togglePlaylistUI(false);
        UI.progress.onclick = seek;
        UI.playlistSearchInput.oninput = handlePlaylistSearch;
        UI.clearSearchBtn.onclick = clearSearch;
        UI.switchSourceBtn.onclick = function(e) {
            e.stopPropagation();
            manualSwitchToNextSource();
        };
        UI.playlistContainer.onmouseleave = () => {
            if (document.activeElement !== UI.playlistSearchInput) {
                state.timers.hidePlaylist = setTimeout(() => togglePlaylistUI(false), 300);
            }
        };
        UI.playlistContainer.onmouseenter = () => {
            if (state.timers.hidePlaylist) clearTimeout(state.timers.hidePlaylist);
        };
    }
    window.addEventListener('beforeunload', function() {
        if (state.timers.refreshPlaylist) {
            clearTimeout(state.timers.refreshPlaylist);
            console.log('[清理] 播放列表刷新定时器已清理');
        }
        if (state.timers.load) {
            clearTimeout(state.timers.load);
            console.log('[清理] 加载定时器已清理');
        }
        if (state.timers.stall) {
            clearTimeout(state.timers.stall);
            console.log('[清理] 卡顿定时器已清理');
        }
        if (state.timers.epgRefresh) {
            clearTimeout(state.timers.epgRefresh);
            console.log('[清理] EPG刷新定时器已清理');
        }
    });
    init();
});