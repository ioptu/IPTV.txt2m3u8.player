document.addEventListener("DOMContentLoaded", function() {
    // DOM 元素
    const tabs = document.querySelectorAll('.tab');
    const tabContents = document.querySelectorAll('.tab-content');
    const backBtn = document.querySelector('.back-btn');
    const saveBtn = document.getElementById('saveBtn');
    const resetBtn = document.getElementById('resetBtn');
    const blacklistInput = document.getElementById('blacklistInput');
    const addKeywordBtn = document.getElementById('addKeywordBtn');
    const blacklistItems = document.getElementById('blacklistItems');
    // 默认配置（与 player.js 中的 CONFIG 对应，单位转换为用户友好的格式）
    const DEFAULT_CONFIG = {
        loadTimeout: 10,            // 秒
        stallTimeout: 5,            // 秒
        maxRetryRounds: 2,          // 轮
        searchDebounce: 300,        // 毫秒
        playlistRefreshInterval: 60, // 分钟
        autoRefreshEnabled: true,
        blacklist: []               // 黑名单关键词数组
    };
    // 当前配置
    let currentConfig = { ...DEFAULT_CONFIG };
    // 初始化标签页切换
    function initTabs() {
        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                const tabId = tab.getAttribute('data-tab');
                // 更新标签状态
                tabs.forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                // 更新内容显示
                tabContents.forEach(content => {
                    content.classList.remove('active');
                });
                const targetTab = document.getElementById(`${tabId}-tab`);
                if (targetTab) {
                    targetTab.classList.add('active');
                }
            });
        });
    }
    // 加载设置
    function loadSettings() {
        chrome.storage.local.get([
            'loadTimeout',
            'stallTimeout',
            'maxRetryRounds',
            'searchDebounce',
            'playlistRefreshInterval',
            'autoRefreshEnabled',
            'blacklist'
        ], function(result) {
            // 加载数值设置（转换为用户友好的单位）
            const loadTimeoutInput = document.getElementById('loadTimeout');
            const stallTimeoutInput = document.getElementById('stallTimeout');
            const maxRetryRoundsInput = document.getElementById('maxRetryRounds');
            const searchDebounceInput = document.getElementById('searchDebounce');
            const playlistRefreshIntervalInput = document.getElementById('playlistRefreshInterval');
            const autoRefreshEnabledInput = document.getElementById('autoRefreshEnabled');
            if (loadTimeoutInput && result.loadTimeout !== undefined) {
                loadTimeoutInput.value = Math.round(result.loadTimeout / 1000);
                currentConfig.loadTimeout = Math.round(result.loadTimeout / 1000);
            }
            if (stallTimeoutInput && result.stallTimeout !== undefined) {
                stallTimeoutInput.value = Math.round(result.stallTimeout / 1000);
                currentConfig.stallTimeout = Math.round(result.stallTimeout / 1000);
            }
            if (maxRetryRoundsInput && result.maxRetryRounds !== undefined) {
                maxRetryRoundsInput.value = result.maxRetryRounds;
                currentConfig.maxRetryRounds = result.maxRetryRounds;
            }
            if (searchDebounceInput && result.searchDebounce !== undefined) {
                searchDebounceInput.value = result.searchDebounce;
                currentConfig.searchDebounce = result.searchDebounce;
            }
            if (playlistRefreshIntervalInput && result.playlistRefreshInterval !== undefined) {
                playlistRefreshIntervalInput.value = Math.round(result.playlistRefreshInterval / 60000);
                currentConfig.playlistRefreshInterval = Math.round(result.playlistRefreshInterval / 60000);
            }
            // 加载复选框设置
            if (autoRefreshEnabledInput && result.autoRefreshEnabled !== undefined) {
                autoRefreshEnabledInput.checked = result.autoRefreshEnabled;
                currentConfig.autoRefreshEnabled = result.autoRefreshEnabled;
            }
            // 加载黑名单
            if (result.blacklist && Array.isArray(result.blacklist)) {
                currentConfig.blacklist = result.blacklist;
                renderBlacklist();
            } else {
                // 如果 storage 中没有黑名单，尝试从文件加载
                loadBlacklistFromFile();
            }
        });
    }
    // 从文件加载黑名单
    function loadBlacklistFromFile() {
        fetch(chrome.runtime.getURL('blacklist.txt'))
            .then(response => response.text())
            .then(text => {
                const keywords = text.split('\n')
                    .map(line => line.trim())
                    .filter(line => line && !line.startsWith('#') && !line.startsWith('//'))
                    .filter(keyword => keyword.length > 0);
                currentConfig.blacklist = keywords;
                renderBlacklist();
            })
            .catch(error => {
                console.warn('无法加载黑名单文件:', error);
                currentConfig.blacklist = [];
                renderBlacklist();
            });
    }
    // 渲染黑名单列表
    function renderBlacklist() {
        if (!blacklistItems) return;
        blacklistItems.innerHTML = '';
        if (currentConfig.blacklist.length === 0) {
            blacklistItems.innerHTML = `
                <div class="empty-state">
                    <div>📝</div>
                    <p>暂无黑名单规则</p>
                    <p class="tip">添加关键词以过滤不需要的内容</p>
                </div>
            `;
            return;
        }
        currentConfig.blacklist.forEach((keyword, index) => {
            const item = document.createElement('div');
            item.className = 'blacklist-item';
            item.innerHTML = `
                <div class="blacklist-keyword">${escapeHtml(keyword)}</div>
                <div class="blacklist-actions">
                    <button class="edit-btn" data-index="${index}">✏️</button>
                    <button class="delete-btn" data-index="${index}">🗑️</button>
                </div>
            `;
            blacklistItems.appendChild(item);
        });
        // 添加事件监听器
        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const index = parseInt(e.target.getAttribute('data-index'));
                editKeyword(index);
            });
        });
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const index = parseInt(e.target.getAttribute('data-index'));
                deleteKeyword(index);
            });
        });
    }
    // 添加关键词
    function addKeyword() {
        if (!blacklistInput) return;
        const keyword = blacklistInput.value.trim();
        if (!keyword) {
            alert('请输入关键词');
            return;
        }
        if (currentConfig.blacklist.includes(keyword)) {
            alert('该关键词已存在');
            return;
        }
        currentConfig.blacklist.push(keyword);
        blacklistInput.value = '';
        renderBlacklist();
        showMessage('关键词已添加');
    }
    // 编辑关键词
    function editKeyword(index) {
        const oldKeyword = currentConfig.blacklist[index];
        const newKeyword = prompt('编辑关键词:', oldKeyword);
        if (newKeyword !== null) {
            const trimmedKeyword = newKeyword.trim();
            if (trimmedKeyword && !currentConfig.blacklist.includes(trimmedKeyword)) {
                currentConfig.blacklist[index] = trimmedKeyword;
                renderBlacklist();
                showMessage('关键词已更新');
            } else if (!trimmedKeyword) {
                alert('关键词不能为空');
            } else {
                alert('该关键词已存在');
            }
        }
    }
    // 删除关键词
    function deleteKeyword(index) {
        if (confirm('确定要删除这个关键词吗？')) {
            currentConfig.blacklist.splice(index, 1);
            renderBlacklist();
            showMessage('关键词已删除');
        }
    }
    // 保存设置
    function saveSettings() {
        // 获取表单值
        const loadTimeoutInput = document.getElementById('loadTimeout');
        const stallTimeoutInput = document.getElementById('stallTimeout');
        const maxRetryRoundsInput = document.getElementById('maxRetryRounds');
        const searchDebounceInput = document.getElementById('searchDebounce');
        const playlistRefreshIntervalInput = document.getElementById('playlistRefreshInterval');
        const autoRefreshEnabledInput = document.getElementById('autoRefreshEnabled');
        if (!loadTimeoutInput || !stallTimeoutInput || !maxRetryRoundsInput || 
            !searchDebounceInput || !playlistRefreshIntervalInput || !autoRefreshEnabledInput) {
            showMessage('表单元素缺失，请刷新页面重试', false);
            return;
        }
        const configToSave = {
            loadTimeout: parseInt(loadTimeoutInput.value) * 1000,
            stallTimeout: parseInt(stallTimeoutInput.value) * 1000,
            maxRetryRounds: parseInt(maxRetryRoundsInput.value),
            searchDebounce: parseInt(searchDebounceInput.value),
            playlistRefreshInterval: parseInt(playlistRefreshIntervalInput.value) * 60000,
            autoRefreshEnabled: autoRefreshEnabledInput.checked,
            blacklist: [...currentConfig.blacklist]  // 深拷贝数组
        };
        // 验证输入
        if (isNaN(configToSave.loadTimeout) || configToSave.loadTimeout < 1000) {
            alert('加载超时时间必须大于等于1秒');
            loadTimeoutInput.focus();
            return;
        }
        if (isNaN(configToSave.stallTimeout) || configToSave.stallTimeout < 1000) {
            alert('卡顿检测时间必须大于等于1秒');
            stallTimeoutInput.focus();
            return;
        }
        if (isNaN(configToSave.maxRetryRounds) || configToSave.maxRetryRounds < 1) {
            alert('最大重试轮次必须大于等于1');
            maxRetryRoundsInput.focus();
            return;
        }
        if (isNaN(configToSave.playlistRefreshInterval) || configToSave.playlistRefreshInterval < 300000) {
            alert('播放列表刷新间隔必须大于等于5分钟');
            playlistRefreshIntervalInput.focus();
            return;
        }
        // 保存到 storage
        chrome.storage.local.set(configToSave, function() {
            showMessage('设置已保存！', true);
            // 通知所有打开的播放器页面
            chrome.runtime.sendMessage({
                action: 'settingsUpdated',
                config: configToSave
            });
        });
    }
    // 恢复默认设置
    function resetSettings() {
        if (!confirm('确定要恢复默认设置吗？这将清除所有自定义设置。')) {
            return;
        }
        // 获取表单元素
        const loadTimeoutInput = document.getElementById('loadTimeout');
        const stallTimeoutInput = document.getElementById('stallTimeout');
        const maxRetryRoundsInput = document.getElementById('maxRetryRounds');
        const searchDebounceInput = document.getElementById('searchDebounce');
        const playlistRefreshIntervalInput = document.getElementById('playlistRefreshInterval');
        const autoRefreshEnabledInput = document.getElementById('autoRefreshEnabled');
        // 重置表单值
        if (loadTimeoutInput) loadTimeoutInput.value = DEFAULT_CONFIG.loadTimeout;
        if (stallTimeoutInput) stallTimeoutInput.value = DEFAULT_CONFIG.stallTimeout;
        if (maxRetryRoundsInput) maxRetryRoundsInput.value = DEFAULT_CONFIG.maxRetryRounds;
        if (searchDebounceInput) searchDebounceInput.value = DEFAULT_CONFIG.searchDebounce;
        if (playlistRefreshIntervalInput) playlistRefreshIntervalInput.value = DEFAULT_CONFIG.playlistRefreshInterval;
        if (autoRefreshEnabledInput) autoRefreshEnabledInput.checked = DEFAULT_CONFIG.autoRefreshEnabled;
        // 重置黑名单
        currentConfig.blacklist = [...DEFAULT_CONFIG.blacklist];
        renderBlacklist();
        // 清除 storage 中的设置
        chrome.storage.local.clear(function() {
            showMessage('已恢复默认设置');
        });
    }
    // 显示消息
    function showMessage(message, isSuccess = false) {
        // 移除现有消息
        const existingMessage = document.querySelector('.message-toast');
        if (existingMessage) {
            existingMessage.remove();
        }
        // 创建新消息
        const messageDiv = document.createElement('div');
        messageDiv.className = `message-toast ${isSuccess ? 'success' : 'info'}`;
        messageDiv.textContent = message;
        messageDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 12px 24px;
            background: ${isSuccess ? '#4CAF50' : '#2196F3'};
            color: white;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 1000;
            animation: slideIn 0.3s ease;
        `;
        document.body.appendChild(messageDiv);
        // 3秒后自动移除
        setTimeout(() => {
            if (messageDiv.parentNode) {
                messageDiv.remove();
            }
        }, 3000);
        // 添加动画样式
        if (!document.querySelector('#message-styles')) {
            const style = document.createElement('style');
            style.id = 'message-styles';
            style.textContent = `
                @keyframes slideIn {
                    from { transform: translateX(100%); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
            `;
            document.head.appendChild(style);
        }
    }
    // HTML 转义
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    // 初始化
    function init() {
        // 确保必要元素存在
        if (tabs.length === 0) {
            console.error('未找到标签页元素');
            return;
        }
        if (tabContents.length === 0) {
            console.error('未找到标签内容元素');
            return;
        }
        initTabs();
        loadSettings();
        // 安全地添加事件监听器
        if (backBtn) {
            backBtn.addEventListener('click', () => {
                window.close();
            });
        }
        if (saveBtn) {
            saveBtn.addEventListener('click', saveSettings);
        }
        if (resetBtn) {
            resetBtn.addEventListener('click', resetSettings);
        }
        if (addKeywordBtn) {
            addKeywordBtn.addEventListener('click', addKeyword);
        }
        if (blacklistInput) {
            blacklistInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    addKeyword();
                }
            });
        }
        // 监听来自其他页面的消息
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            if (message.action === 'updateBlacklist') {
                currentConfig.blacklist = message.blacklist || [];
                renderBlacklist();
            }
        });
    }
    // 启动初始化
    init();
});