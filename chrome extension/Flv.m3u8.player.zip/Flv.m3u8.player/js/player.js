document.addEventListener("DOMContentLoaded", function() {
    // 默认配置（使用毫秒）
    const DEFAULT_CONFIG = {
        LOAD_TIMEOUT_MS: 10000,      // 10秒
        STALL_TIMEOUT_MS: 5000,      // 5秒
        MAX_RETRY_ROUNDS: 2,         // 2轮
        SEARCH_DEBOUNCE_MS: 300,     // 300毫秒
        PLAYLIST_REFRESH_INTERVAL: 1000 * 60 * 60,  // 60分钟
        AUTO_REFRESH_ENABLED: true,                 // 启用自动刷新
        BLACKLIST_URL: chrome.runtime.getURL('blacklist.txt') // 黑名单文件URL
    };
    // 实际使用的配置（会被用户设置覆盖）
    const CONFIG = { ...DEFAULT_CONFIG };
    const state = {
        player: null,
        isPlaying: false,
        videoUrl: "",
        baseUrl: "",
        currentPlaylist: [],
        originalPlaylistUrl: "",
        currentPlaylistIndex: -1,
        isM3UPlaylist: false,
        streamInfo: {
            resolution: "未知",
            type: "未知"
        },
        loadRequestId: 0,
        timers: {
            load: null,
            stall: null,
            controls: null,
            hidePlaylist: null,
            searchDebounce: null,
            refreshPlaylist: null
        },
        currentChannelInfo: {
            title: "",
            originalIndex: -1,
            urls: []
        },
        blacklist: [],           // 黑名单关键词数组
        isBlacklistLoaded: false // 黑名单是否已加载
    };
    const UI = {
        videoPlayer: document.getElementById("videoPlayer"),
        videoInfo: document.getElementById("videoInfo"),
        videoContainer: document.querySelector(".video-container"),
        controls: document.getElementById("controls"),
        playPauseBtn: document.getElementById("playPauseBtn"),
        backBtn: document.getElementById("backBtn"),
        prevChannelBtn: document.getElementById("prevChannelBtn"),
        nextChannelBtn: document.getElementById("nextChannelBtn"),
        volumeBtn: document.getElementById("volumeBtn"),
        fullscreenBtn: document.getElementById("fullscreenBtn"),
        playlistBtn: document.getElementById("playlistBtn"),
        closePlaylistBtn: document.getElementById("closePlaylistBtn"),
        clearSearchBtn: document.getElementById("clearSearchBtn"),
        infoBtn: null,
        progress: document.getElementById("progress"),
        progressBar: document.getElementById("progressBar"),
        timeDisplay: document.getElementById("time"),
        volumeSlider: document.getElementById("volumeSlider"),
        volumeProgress: document.getElementById("volumeProgress"),
        volumeContainer: document.querySelector(".volume-container"),
        playlistContainer: document.getElementById("playlist-container"),
        playlistItems: document.getElementById("playlist-items"),
        playlistSearchInput: document.getElementById("playlist-search-input"),
        loading: document.getElementById("loading"),
        errorMessage: document.getElementById("errorMessage"),
        infoPanel: null,
        switchSourceBtn: null
    };
    function init() {
        addStyles();
        createDynamicUI();
        loadVolumeSettings();
        loadSettings();          // 从 storage 加载用户设置
        loadBlacklist();         // 加载黑名单
        parseInitialUrl();
        initGlobalEvents();
        addButtonHoverEffects();
        if (state.videoUrl) {
            UI.videoInfo.textContent = decodeURIComponent(state.videoUrl);
        }
    }
    // 新增：从 storage 加载用户设置
    function loadSettings() {
        chrome.storage.local.get([
            'loadTimeout',
            'stallTimeout',
            'maxRetryRounds',
            'searchDebounce',
            'playlistRefreshInterval',
            'autoRefreshEnabled'
        ], function(result) {
            // 更新 CONFIG（将用户友好的单位转换为毫秒）
            if (result.loadTimeout !== undefined) {
                CONFIG.LOAD_TIMEOUT_MS = result.loadTimeout;
            }
            if (result.stallTimeout !== undefined) {
                CONFIG.STALL_TIMEOUT_MS = result.stallTimeout;
            }
            if (result.maxRetryRounds !== undefined) {
                CONFIG.MAX_RETRY_ROUNDS = result.maxRetryRounds;
            }
            if (result.searchDebounce !== undefined) {
                CONFIG.SEARCH_DEBOUNCE_MS = result.searchDebounce;
            }
            if (result.playlistRefreshInterval !== undefined) {
                CONFIG.PLAYLIST_REFRESH_INTERVAL = result.playlistRefreshInterval;
            }
            if (result.autoRefreshEnabled !== undefined) {
                CONFIG.AUTO_REFRESH_ENABLED = result.autoRefreshEnabled;
            }
            console.log('[设置] 配置已从 storage 加载');
            console.log('[设置] 加载超时:', CONFIG.LOAD_TIMEOUT_MS, 'ms');
            console.log('[设置] 卡顿超时:', CONFIG.STALL_TIMEOUT_MS, 'ms');
            console.log('[设置] 最大重试轮次:', CONFIG.MAX_RETRY_ROUNDS);
            console.log('[设置] 列表刷新间隔:', CONFIG.PLAYLIST_REFRESH_INTERVAL, 'ms');
            console.log('[设置] 自动刷新:', CONFIG.AUTO_REFRESH_ENABLED);
        });
    }
    // 新增：监听设置更新消息
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.action === 'settingsUpdated') {
            console.log('[设置] 收到设置更新通知');
            // 更新 CONFIG
            if (message.config.loadTimeout) {
                CONFIG.LOAD_TIMEOUT_MS = message.config.loadTimeout;
                console.log('[设置] 更新加载超时:', CONFIG.LOAD_TIMEOUT_MS, 'ms');
            }
            if (message.config.stallTimeout) {
                CONFIG.STALL_TIMEOUT_MS = message.config.stallTimeout;
                console.log('[设置] 更新卡顿超时:', CONFIG.STALL_TIMEOUT_MS, 'ms');
            }
            if (message.config.maxRetryRounds) {
                CONFIG.MAX_RETRY_ROUNDS = message.config.maxRetryRounds;
                console.log('[设置] 更新最大重试轮次:', CONFIG.MAX_RETRY_ROUNDS);
            }
            if (message.config.searchDebounce) {
                CONFIG.SEARCH_DEBOUNCE_MS = message.config.searchDebounce;
                console.log('[设置] 更新搜索防抖:', CONFIG.SEARCH_DEBOUNCE_MS, 'ms');
            }
            if (message.config.playlistRefreshInterval) {
                CONFIG.PLAYLIST_REFRESH_INTERVAL = message.config.playlistRefreshInterval;
                console.log('[设置] 更新列表刷新间隔:', CONFIG.PLAYLIST_REFRESH_INTERVAL, 'ms');
                // 如果正在播放M3U列表，重启刷新定时器
                if (state.isM3UPlaylist && CONFIG.AUTO_REFRESH_ENABLED) {
                    if (state.timers.refreshPlaylist) {
                        clearTimeout(state.timers.refreshPlaylist);
                    }
                    startPlaylistRefreshTimer();
                }
            }
            if (message.config.autoRefreshEnabled !== undefined) {
                CONFIG.AUTO_REFRESH_ENABLED = message.config.autoRefreshEnabled;
                console.log('[设置] 更新自动刷新:', CONFIG.AUTO_REFRESH_ENABLED);
                if (!CONFIG.AUTO_REFRESH_ENABLED && state.timers.refreshPlaylist) {
                    clearTimeout(state.timers.refreshPlaylist);
                    state.timers.refreshPlaylist = null;
                } else if (CONFIG.AUTO_REFRESH_ENABLED && state.isM3UPlaylist) {
                    startPlaylistRefreshTimer();
                }
            }
            if (message.config.blacklist) {
                state.blacklist = message.config.blacklist;
                state.isBlacklistLoaded = true;
                console.log(`[设置] 黑名单已更新，${state.blacklist.length} 个关键词`);
            }
            // 更新信息面板
            updateInfoPanel();
            showNotification('设置已更新', 2000);
        }
    });
    // 修改后的 loadBlacklist 函数：优先从 storage，没有则从文件
    function loadBlacklist() {
        state.blacklist = [];
        state.isBlacklistLoaded = false;
        console.log('[黑名单] 开始加载黑名单...');
        // 1. 首先尝试从 storage 加载（用户自定义的）
        chrome.storage.local.get(['blacklist', 'blacklistContent'], function(result) {
            if (result.blacklist && Array.isArray(result.blacklist) && result.blacklist.length > 0) {
                // 从 storage 的数组加载成功
                state.blacklist = result.blacklist;
                console.log(`[黑名单] 从 storage 加载 ${state.blacklist.length} 个关键词`);
                state.isBlacklistLoaded = true;
                if (state.videoUrl) startVideoLoadProcess();
            } else if (result.blacklistContent) {
                // 从 storage 的字符串内容加载
                state.blacklist = result.blacklistContent.split('\n')
                    .map(line => line.trim())
                    .filter(line => line && !line.startsWith('#') && !line.startsWith('//'))
                    .filter(keyword => keyword.length > 0);
                console.log(`[黑名单] 从 storage 内容加载 ${state.blacklist.length} 个关键词`);
                state.isBlacklistLoaded = true;
                if (state.videoUrl) startVideoLoadProcess();
            } else {
                // 2. storage 中没有，则从文件加载
                console.log('[黑名单] storage 中无黑名单，尝试从文件加载');
                fetch(CONFIG.BLACKLIST_URL)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error(`HTTP ${response.status}`);
                        }
                        return response.text();
                    })
                    .then(text => {
                        state.blacklist = text.split('\n')
                            .map(line => line.trim())
                            .filter(line => line && !line.startsWith('#') && !line.startsWith('//'))
                            .filter(keyword => keyword.length > 0);
                        console.log(`[黑名单] 从文件加载 ${state.blacklist.length} 个关键词`);
                        state.isBlacklistLoaded = true;
                        if (state.videoUrl) startVideoLoadProcess();
                    })
                    .catch(error => {
                        console.warn('[黑名单] 文件加载失败，使用空黑名单:', error);
                        state.blacklist = [];
                        state.isBlacklistLoaded = true;
                        if (state.videoUrl) startVideoLoadProcess();
                    });
            }
        });
    }
    // 新增：为所有控制按钮添加统一的鼠标效果
    function addButtonHoverEffects() {
        const staticButtons = [
            UI.backBtn,
            UI.playPauseBtn,
            UI.prevChannelBtn,
            UI.nextChannelBtn,
            UI.volumeBtn,
            UI.fullscreenBtn,
            UI.playlistBtn,
            UI.closePlaylistBtn,
            UI.clearSearchBtn
        ];
        staticButtons.forEach(button => {
            if (!button) return;
            setupButtonHoverEffects(button);
        });
    }
    function setupButtonHoverEffects(button) {
        if (!button) return;
        button.style.opacity = '1';
        button.style.transition = 'opacity 0.2s ease';
        button.addEventListener('mouseenter', () => {
            button.style.opacity = '0.8';
        });
        button.addEventListener('mouseleave', () => {
            button.style.opacity = '1';
        });
        button.addEventListener('mousedown', () => {
            button.style.opacity = '0.6';
        });
        button.addEventListener('mouseup', () => {
            button.style.opacity = '0.8';
        });
    }
    function addStyles() {
        const style = document.createElement('style');
        style.textContent = `
            .switch-source-btn:hover {
                background: rgba(255, 255, 255, 0.2);
                border-radius: 3px;
                transform: scale(1);
                transition: all 0.2s ease;
            }
            .switch-source-btn:active {
                transform: scale(1);
                transition: all 0.1s ease;
            }
            .info-panel {
                font-size: 12px;
                line-height: 1.4;
            }
            @keyframes fadeInOut {
                0% { opacity: 0; transform: translate(-50%, -10px); }
                15% { opacity: 1; transform: translate(-50%, 0); }
                85% { opacity: 1; transform: translate(-50%, 0); }
                100% { opacity: 0; transform: translate(-50%, -10px); }
            }
            .blacklist-error {
                background: linear-gradient(135deg, #ff6b6b, #c92a2a) !important;
                border: 2px solid #ff6b6b !important;
                color: white !important;
                font-weight: bold !important;
                padding: 15px !important;
                border-radius: 8px !important;
            }
        `;
        document.head.appendChild(style);
    }
    function createDynamicUI() {
        UI.infoBtn = document.createElement("button");
        UI.infoBtn.className = "info-btn";
        UI.infoBtn.innerHTML = "ⓘ";
        UI.infoBtn.title = "播放信息";
        UI.infoBtn.style.cssText = "background:none; border:none; color:white; cursor:pointer; margin-left:10px;";
        UI.volumeContainer.insertAdjacentElement("afterend", UI.infoBtn);
        setupButtonHoverEffects(UI.infoBtn);
        UI.infoPanel = document.createElement("div");
        UI.infoPanel.className = "info-panel";
        UI.infoPanel.style.cssText = "display:none; position:absolute; bottom:60px; right:10px; background:rgba(0,0,0,0.8); padding:10px; border-radius:4px; font-size:12px; z-index: 20;";
        UI.videoContainer.appendChild(UI.infoPanel);
        UI.switchSourceBtn = document.createElement("button");
        UI.switchSourceBtn.className = "switch-source-btn";
        UI.switchSourceBtn.innerHTML = "⥮";
        UI.switchSourceBtn.title = "手动换源";
        UI.switchSourceBtn.style.cssText = "background:none; border:none; color:white; cursor:pointer; margin-left:10px; font-size:16px;";
        UI.infoBtn.insertAdjacentElement("afterend", UI.switchSourceBtn);
        setupButtonHoverEffects(UI.switchSourceBtn);
    }
    function loadVolumeSettings() {
        chrome.storage.local.get(["volume"], function(result) {
            if (result.volume !== undefined) {
                UI.videoPlayer.volume = result.volume;
                UI.volumeProgress.style.width = result.volume * 100 + "%";
                updateVolumeIcon();
            }
        });
    }
    function switchToPrevChannel() {
        if (!state.isM3UPlaylist || state.currentPlaylist.length === 0) {
            showNotification("当前不是播放列表模式或列表为空", 1500);
            return;
        }
        if (state.currentPlaylistIndex === -1) {
            state.currentPlaylistIndex = 0;
        }
        let prevIndex = state.currentPlaylistIndex - 1;
        if (prevIndex < 0) {
            prevIndex = state.currentPlaylist.length - 1;
        }
        console.log(`[频道切换] 切换到上一个频道: ${state.currentPlaylistIndex} → ${prevIndex}`);
        const item = state.currentPlaylist[prevIndex];
        if (item) {
            showNotification(`切换到上一个频道: ${item.title || `频道 ${prevIndex + 1}`}`, 1500);
        }
        playPlaylistItem(prevIndex);
    }
    function switchToNextChannel() {
        if (!state.isM3UPlaylist || state.currentPlaylist.length === 0) {
            showNotification("当前不是播放列表模式或列表为空", 1500);
            return;
        }
        if (state.currentPlaylistIndex === -1) {
            state.currentPlaylistIndex = 0;
        }
        let nextIndex = state.currentPlaylistIndex + 1;
        if (nextIndex >= state.currentPlaylist.length) {
            nextIndex = 0;
        }
        console.log(`[频道切换] 切换到下一个频道: ${state.currentPlaylistIndex} → ${nextIndex}`);
        const item = state.currentPlaylist[nextIndex];
        if (item) {
            showNotification(`切换到下一个频道: ${item.title || `频道 ${nextIndex + 1}`}`, 1500);
        }
        playPlaylistItem(nextIndex);
    }
    function parseInitialUrl() {
        const urlParams = new URLSearchParams(window.location.search);
        const queryUrl = urlParams.get("url");
        const hashUrl = window.location.hash.substring(1);
        state.videoUrl = queryUrl || hashUrl;
        if (state.videoUrl) {
            UI.videoInfo.textContent = decodeURIComponent(state.videoUrl);
            try {
                const urlObj = new URL(state.videoUrl);
                state.baseUrl = urlObj.href.substring(0, urlObj.href.lastIndexOf("/") + 1);
                state.originalPlaylistUrl = state.videoUrl;
            } catch (e) {
                console.warn("基础URL解析失败:", e);
                state.baseUrl = "";
                state.originalPlaylistUrl = state.videoUrl;
            }
        }
    }
    function clearTimers(keys = []) {
        const targets = keys.length > 0 ? keys : ["load", "stall"];
        targets.forEach(key => {
            if (state.timers[key]) {
                clearTimeout(state.timers[key]);
                state.timers[key] = null;
            }
        });
    }
    function showLoading(show) {
        UI.loading.style.display = show ? "block" : "none";
    }
    function showError(message) {
        showLoading(false);
        UI.errorMessage.textContent = message;
        UI.errorMessage.style.display = "block";
        if (message.includes("黑名单") || message.includes("拦截") || message.includes("禁止")) {
            UI.errorMessage.classList.add("blacklist-error");
        } else {
            UI.errorMessage.classList.remove("blacklist-error");
        }
    }
    function formatTime(seconds) {
        if (seconds === Infinity || isNaN(seconds)) return "Live";
        const m = Math.floor(seconds / 60);
        const s = Math.floor(seconds % 60);
        return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
    }
    function startVideoLoadProcess() {
        showLoading(true);
        UI.errorMessage.style.display = "none";
        UI.errorMessage.classList.remove("blacklist-error");
        checkAndInitPlayer(state.videoUrl);
    }
    // 新增：检查URL是否包含黑名单关键词
    function checkUrlInBlacklist(url, urlType = "URL") {
        if (!url || typeof url !== 'string') {
            return false;
        }
        // 等待黑名单加载完成
        if (!state.isBlacklistLoaded) {
            console.log(`[黑名单] 等待黑名单加载完成...`);
            setTimeout(() => {
                checkUrlInBlacklist(url, urlType);
            }, 100);
            return false;
        }
        const lowerUrl = url.toLowerCase();
        for (const keyword of state.blacklist) {
            if (!keyword) continue;
            const lowerKeyword = keyword.toLowerCase();
            // 支持简单的通配符匹配
            if (lowerKeyword.includes('*')) {
                // 将通配符转换为正则表达式
                const pattern = lowerKeyword
                    .replace(/\./g, '\\.')
                    .replace(/\*/g, '.*');
                const regex = new RegExp(`^${pattern}$`);
                if (regex.test(lowerUrl)) {
                    console.warn(`[黑名单拦截] ${urlType} 匹配通配符模式: "${keyword}"`);
                    console.warn(`[黑名单拦截] 被拦截的URL: ${url}`);
                    showError(
                        `播放被拦截：链接匹配黑名单规则\n\n` +
                        `规则: ${keyword}\n` +
                        `URL: ${url.substring(0, 80)}${url.length > 80 ? '...' : ''}`
                    );
                    handleBlacklistedInPlaylist(url, keyword);
                    return true;
                }
            } else if (lowerUrl.includes(lowerKeyword)) {
                console.warn(`[黑名单拦截] ${urlType} 包含黑名单关键词: "${keyword}"`);
                console.warn(`[黑名单拦截] 被拦截的URL: ${url}`);
                showError(
                    `播放被拦截：链接包含黑名单关键词\n\n` +
                    `关键词: ${keyword}\n` +
                    `URL: ${url.substring(0, 80)}${url.length > 80 ? '...' : ''}`
                );
                handleBlacklistedInPlaylist(url, keyword);
                return true;
            }
        }
        return false;
    }
    // 新增：处理播放列表中被黑名单拦截的项目
    function handleBlacklistedInPlaylist(blockedUrl, keyword) {
        if (!state.isM3UPlaylist || state.currentPlaylistIndex === -1) {
            return;
        }
        const item = state.currentPlaylist[state.currentPlaylistIndex];
        if (!item) return;
        // 从当前频道的URL列表中移除被拦截的URL
        if (item.urls && item.urls.length > 0) {
            const originalLength = item.urls.length;
            item.urls = item.urls.filter(url => url !== blockedUrl);
            if (item.urls.length < originalLength) {
                console.warn(`[黑名单] 从频道 "${item.title}" 中移除 ${originalLength - item.urls.length} 个被拦截的源`);
                // 更新当前频道信息
                if (state.currentChannelInfo.urls) {
                    state.currentChannelInfo.urls = state.currentChannelInfo.urls.filter(url => url !== blockedUrl);
                }
                // 如果当前正在播放被拦截的源，切换到下一个源
                if (item.currentUrlIndex !== undefined && 
                    item.urls.length > 0 && 
                    item.currentUrlIndex >= item.urls.length) {
                    item.currentUrlIndex = 0;
                    showNotification(`源被黑名单拦截，自动切换`, 2000);
                    // 自动播放下一个源
                    const nextUrl = item.urls[0];
                    setTimeout(() => {
                        if (checkUrlInBlacklist(nextUrl, "下一个源")) {
                            return;
                        }
                        destroyPlayer();
                        showLoading(true);
                        UI.errorMessage.style.display = "none";
                        UI.videoInfo.textContent = item.title || decodeURIComponent(nextUrl);
                        checkAndInitPlayer(nextUrl);
                    }, 1500);
                }
            }
            // 如果频道所有源都被拦截，跳过这个频道
            if (item.urls.length === 0) {
                console.warn(`[黑名单] 频道 "${item.title}" 所有源均被拦截，将跳过`);
                showNotification(`频道 "${item.title}" 已被屏蔽`, 3000);
                // 自动播放下一个频道
                setTimeout(() => {
                    let nextIndex = state.currentPlaylistIndex + 1;
                    while (nextIndex < state.currentPlaylist.length) {
                        const nextItem = state.currentPlaylist[nextIndex];
                        if (nextItem && nextItem.urls && nextItem.urls.length > 0) {
                            // 检查下一个频道的第一个URL是否在黑名单中
                            const firstUrl = nextItem.urls[0];
                            if (!checkUrlInBlacklist(firstUrl, "下一个频道URL")) {
                                playPlaylistItem(nextIndex);
                                return;
                            }
                        }
                        nextIndex++;
                    }
                    // 所有频道都被屏蔽
                    showError("所有频道均被黑名单拦截，无法播放");
                }, 1500);
            }
        }
    }
    function checkAndInitPlayer(url) {
        const thisRequestId = ++state.loadRequestId;
        // 等待黑名单加载完成
        if (!state.isBlacklistLoaded) {
            console.log(`[Req #${thisRequestId}] 等待黑名单加载...`);
            setTimeout(() => {
                if (thisRequestId === state.loadRequestId) {
                    checkAndInitPlayer(url);
                }
            }, 100);
            return;
        }
        // 检查URL是否在黑名单中（包括原始URL）
        if (checkUrlInBlacklist(url, "原始URL")) {
            return;
        }
        const lowerUrl = url.toLowerCase();
        //if (/(?:\.(flv|m3u8|m3u)|#m3u8|#m3u)([?#].*)?$/.test(lowerUrl)) {
		if (/(?:#m3u8|#m3u)([?#].*)?$/.test(lowerUrl)) {	
            if (thisRequestId === state.loadRequestId) {
                initPlayerWithUrl(url);
            }
        } else {
            console.log(`[Req #${thisRequestId}] 检测重定向及 Content-Type:`, url);
            new Promise(resolve => {
                chrome.runtime.sendMessage({
                    action: "checkRedirect",
                    url: url
                }, response => resolve(response));
            }).then(response => {
                if (thisRequestId !== state.loadRequestId) {
                    console.warn(`[Req #${thisRequestId}] 请求已过期 (当前ID: ${state.loadRequestId})，丢弃结果。`);
                    return;
                }
                if (response && response.success) {
                    console.log(`[Req #${thisRequestId}] 重定向成功: ${response.finalUrl}`);
                    // 检查重定向后的URL是否在黑名单中
                    if (checkUrlInBlacklist(response.finalUrl, "重定向URL")) {
                        return;
                    }
                    initPlayerWithUrl(response.finalUrl, response.contentType || "");
                } else {
                    console.warn(`[Req #${thisRequestId}] 重定向检测无响应或失败，尝试直连`);
                    initPlayerWithUrl(url);
                }
            });
        }
    }
    function destroyPlayer() {
        if (state.player) {
            if (typeof state.player.destroy === "function") {
                state.player.destroy();
            } else if (state.player instanceof Hls) {
                state.player.destroy();
            }
            state.player = null;
        }
        UI.videoPlayer.removeAttribute("src");
        UI.videoPlayer.load();
        state.isPlaying = false;
        clearTimers();
        state.streamInfo = {
            resolution: "未知",
            type: "未知"
        };
    }
    function initPlayerWithUrl(url, contentType = "") {
        // 再次检查URL（以防万一）
        if (checkUrlInBlacklist(url, "播放URL")) {
            return;
        }
        const lowerUrl = url.toLowerCase();
        const ct = contentType.toLowerCase();
        const isHlsContent = ct.includes("mpegurl") || ct.includes("hls") || ct.includes("text/html") || ct.includes("text/plain") || ct.includes("application/octet-stream");
        if (/(?:[.]m3u|#m3u)([?#].*)?$/.test(lowerUrl)) {
            state.streamInfo.type = "M3U";
            initM3UPlaylist(url);
        } else if (isHlsContent || /(?:[.]m3u8|#m3u8)([?#].*)?$/.test(lowerUrl)) {
            state.streamInfo.type = isHlsContent ? "HLS (Type)" : "HLS";
            initHlsPlayer(url);
        } else if (/\.flv([?#].*)?$/.test(lowerUrl)) {
            state.streamInfo.type = "FLV";
            initFlvPlayer(url);
        } else {
            state.streamInfo.type = "原生";
            initNativePlayer(url);
        }
    }
    function initFlvPlayer(url) {
        if (!flvjs.isSupported()) {
            return handleError("您的浏览器不支持FLV播放");
        }
        destroyPlayer();
        const player = flvjs.createPlayer({
            type: "flv",
            url: url
        });
        player.attachMediaElement(UI.videoPlayer);
        player.load();
        player.on(flvjs.Events.METADATA_ARRIVED, metadata => {
            clearTimers(["load"]);
            if (metadata?.onMetaData) {
                const { width, height } = metadata.onMetaData;
                if (width && height) state.streamInfo.resolution = `${width}x${height}`;
                updateInfoPanel();
            }
        });
        player.on(flvjs.Events.ERROR, (type, detail) => {
            console.error("FLV Error:", type, detail);
            handleError(`FLV播放错误: ${type}`);
        });
        state.player = player;
        attachCommonVideoEvents();
    }
    function initHlsPlayer(url) {
        if (Hls.isSupported()) {
            destroyPlayer();
            const player = new Hls({
                debug: false,
                capLevelToPlayerSize: true,
                autoLevelEnabled: true,
                fragLoadingMaxRetry: 1,
                fragLoadingRetryDelay: 500
            });
            player.loadSource(url);
            player.attachMedia(UI.videoPlayer);
            player.on(Hls.Events.MANIFEST_PARSED, (event, data) => {
                clearTimers(["load"]);
                console.log("HLS Manifest Parsed");
                showLoading(false);
                updateResolutionFromHls(player, data);
                attemptPlay();
            });
            player.on(Hls.Events.ERROR, (event, data) => {
                if (data.fatal) {
                    console.error("HLS Fatal Error:", data.type, data.details);
                    handleError(`HLS播放错误: ${data.details}`);
                }
            });
            state.player = player;
            attachCommonVideoEvents();
        } else if (UI.videoPlayer.canPlayType("application/vnd.apple.mpegurl")) {
            destroyPlayer();
            UI.videoPlayer.src = url;
            attachCommonVideoEvents();
        } else {
            handleError("您的浏览器不支持HLS播放");
        }
    }
    function initNativePlayer(url) {
        destroyPlayer();
        const lower = url.toLowerCase();
        if (lower.includes(".mp4")) state.streamInfo.type = "MP4";
        else if (lower.includes(".webm")) state.streamInfo.type = "WebM";
        else if (lower.includes(".ogg") || lower.includes(".ogv")) state.streamInfo.type = "OGG";
        UI.videoPlayer.src = url;
        attachCommonVideoEvents();
    }
    function attachCommonVideoEvents() {
        UI.videoPlayer.onloadedmetadata = function() {
            clearTimers(["load"]);
            showLoading(false);
            updateVideoInfoFromElement();
            attemptPlay();
        };
        UI.videoPlayer.onloadeddata = function() {
            updateVideoInfoFromElement();
        };
        UI.videoPlayer.onerror = function() {
            if (!UI.videoPlayer.getAttribute("src") && !UI.videoPlayer.currentSrc) return;
            handleError("视频加载失败或格式不支持");
        };
        UI.videoPlayer.onplay = () => {
            state.isPlaying = true;
            UI.playPauseBtn.textContent = "❚❚";
            UI.playPauseBtn.title = "暂停";
        };
        UI.videoPlayer.onpause = () => {
            state.isPlaying = false;
            UI.playPauseBtn.textContent = "▶";
            UI.playPauseBtn.title = "播放";
        };
        UI.videoPlayer.ontimeupdate = updateProgress;
        UI.videoPlayer.onvolumechange = updateVolumeIcon;
        UI.videoPlayer.onended = () => {
            if (state.isM3UPlaylist) {
                const item = state.currentPlaylist[state.currentPlaylistIndex];
                if (item && item.urls && item.currentUrlIndex < item.urls.length - 1) {
                    item.currentUrlIndex++;
                    console.log(`当前源播放结束，切换至本频道下一个源: ${item.currentUrlIndex + 1}/${item.urls.length}`);
                    showNotification(`播放结束，切换到源 ${item.currentUrlIndex + 1}/${item.urls.length}`, 1500);
                    const nextUrl = item.urls[item.currentUrlIndex];
                    destroyPlayer();
                    showLoading(true);
                    UI.errorMessage.style.display = "none";
                    UI.videoInfo.textContent = item.title || decodeURIComponent(nextUrl);
                    checkAndInitPlayer(nextUrl);
                    if (state.timers.load) clearTimeout(state.timers.load);
                    state.timers.load = setTimeout(() => {
                        console.error(`加载超时 (${CONFIG.LOAD_TIMEOUT_MS}ms)，切换线路。`);
                        tryNextRedundantUrl();
                    }, CONFIG.LOAD_TIMEOUT_MS);
                    return;
                }
                if (state.currentPlaylistIndex < state.currentPlaylist.length - 1) {
                    playPlaylistItem(state.currentPlaylistIndex + 1);
                }
            }
        };
        UI.videoPlayer.onwaiting = () => {
            if (state.isM3UPlaylist && state.isPlaying) {
                console.warn(`卡顿检测: 启动超时计时器 (${CONFIG.STALL_TIMEOUT_MS}ms)`);
                if (state.timers.stall) clearTimeout(state.timers.stall);
                state.timers.stall = setTimeout(() => {
                    console.error("播放停滞超时，尝试切换线路。");
                    showNotification("卡顿超时，自动换源", 1500);
                    tryNextRedundantUrl();
                }, CONFIG.STALL_TIMEOUT_MS);
            }
        };
        UI.videoPlayer.onplaying = () => {
            if (state.timers.stall) {
                clearTimeout(state.timers.stall);
                state.timers.stall = null;
            }
        };
    }
    function handleError(msg) {
        if (state.isM3UPlaylist) {
            console.warn(`捕获错误: ${msg} -> 尝试下一个源`);
            tryNextRedundantUrl();
        } else {
            showError(msg);
        }
    }
    let isFirstPlay = true;
    function attemptPlay() {
        const promise = UI.videoPlayer.play();
        if (promise !== undefined) {
            promise.then(() => {
                state.isPlaying = true;
                UI.playPauseBtn.textContent = "❚❚";
                UI.playPauseBtn.title = "暂停";
                if (isFirstPlay && !document.fullscreenElement) {
                    isFirstPlay = false;
                }
            }).catch(error => {
                console.error("自动播放被阻止或失败:", error);
                state.isPlaying = false;
                UI.playPauseBtn.textContent = "▶";
                UI.playPauseBtn.title = "播放";
            });
        }
    }
    function initM3UPlaylist(url) {
        state.isM3UPlaylist = true;
        const parser = new M3UParser;
        parser.parseFromUrl(url).then(playlist => {
            if (!playlist || playlist.length === 0) {
                throw new Error("播放列表为空");
            }
            const processedPlaylist = playlist.map(item => {
                const rawUrls = item.urls && item.urls.length > 0 ? item.urls : [item.url];
                const validUrls = rawUrls.filter(u => u).map(u => {
                    if (!u.startsWith("http") && !u.startsWith("//")) {
                        return M3UParser.resolveUrl(state.baseUrl, u);
                    }
                    return u;
                });
                item.urls = validUrls;
                return item;
            }).filter(item => item.urls.length > 0);
            if (processedPlaylist.length === 0) {
                throw new Error("解析后无有效项目");
            }
            if (state.currentPlaylist.length === 0) {
                state.currentPlaylist = processedPlaylist;
                renderPlaylist();
                playPlaylistItem(0);
                togglePlaylistUI(true);
                if (CONFIG.AUTO_REFRESH_ENABLED) {
                    startPlaylistRefreshTimer();
                }
            } else {
                refreshPlaylist(processedPlaylist);
            }
        }).catch(err => {
            console.error("M3U解析失败:", err);
            showError("解析播放列表失败: " + err.message);
        });
    }
    function startPlaylistRefreshTimer() {
        if (state.timers.refreshPlaylist) {
            clearTimeout(state.timers.refreshPlaylist);
            state.timers.refreshPlaylist = null;
        }
        if (!CONFIG.AUTO_REFRESH_ENABLED) {
            console.log('[定时刷新] 自动刷新已禁用');
            return;
        }
        if (CONFIG.PLAYLIST_REFRESH_INTERVAL <= 0) {
            console.log('[定时刷新] 刷新间隔为0，不启用定时刷新');
            return;
        }
        state.timers.refreshPlaylist = setTimeout(() => {
            console.log(`[定时刷新] 开始刷新播放列表...`);
            refreshM3UPlaylist();
        }, CONFIG.PLAYLIST_REFRESH_INTERVAL);
        console.log(`[定时刷新] 已设置定时器，${Math.round(CONFIG.PLAYLIST_REFRESH_INTERVAL/1000)}秒后刷新`);
    }
    function refreshM3UPlaylist() {
        if (!state.isM3UPlaylist || !state.originalPlaylistUrl) {
            console.warn("[定时刷新] 当前不是M3U播放列表或缺少原始URL");
            startPlaylistRefreshTimer();
            return;
        }
        console.log(`[定时刷新] 刷新播放列表: ${state.originalPlaylistUrl}`);
        const parser = new M3UParser;
        parser.parseFromUrl(state.originalPlaylistUrl).then(playlist => {
            if (!playlist || playlist.length === 0) {
                console.warn("[定时刷新] 刷新的播放列表为空");
                startPlaylistRefreshTimer();
                return;
            }
            const processedPlaylist = playlist.map(item => {
                const rawUrls = item.urls && item.urls.length > 0 ? item.urls : [item.url];
                const validUrls = rawUrls.filter(u => u).map(u => {
                    if (!u.startsWith("http") && !u.startsWith("//")) {
                        return M3UParser.resolveUrl(state.baseUrl, u);
                    }
                    return u;
                });
                item.urls = validUrls;
                return item;
            }).filter(item => item.urls.length > 0);
            if (processedPlaylist.length === 0) {
                console.warn("[定时刷新] 解析后无有效项目");
                startPlaylistRefreshTimer();
                return;
            }
            refreshPlaylist(processedPlaylist);
            startPlaylistRefreshTimer();
        }).catch(err => {
            console.error("[定时刷新] M3U解析失败:", err);
            startPlaylistRefreshTimer();
        });
    }
    function refreshPlaylist(newPlaylist) {
        console.log('[定时刷新] 开始刷新播放列表...');
        const oldIndex = state.currentPlaylistIndex;
        const oldItem = oldIndex >= 0 ? state.currentPlaylist[oldIndex] : null;
        if (oldItem) {
            state.currentChannelInfo = {
                title: oldItem.title || "",
                originalIndex: oldIndex,
                urls: [...oldItem.urls],
                currentUrlIndex: oldItem.currentUrlIndex || 0,
                currentRound: oldItem.currentRound || 1
            };
            console.log(`[定时刷新] 保存当前频道: "${state.currentChannelInfo.title}"`);
        }
        const oldPlaylist = [...state.currentPlaylist];
        state.currentPlaylist = newPlaylist;
        let newIndex = -1;
        if (state.currentChannelInfo.title) {
            newIndex = state.currentPlaylist.findIndex(item =>
                item.title === state.currentChannelInfo.title
            );
            if (newIndex === -1 && state.currentChannelInfo.urls.length > 0) {
                newIndex = state.currentPlaylist.findIndex(item =>
                    item.urls && item.urls.some(url =>
                        state.currentChannelInfo.urls.includes(url)
                    )
                );
            }
        }
        if (newIndex === -1) {
            console.log(`[定时刷新] 当前频道在新列表中不存在，继续播放原频道`);
            if (oldItem) {
                const preservedItem = {
                    ...oldItem,
                    title: oldItem.title ? `${oldItem.title} (旧列表)` : "旧列表频道"
                };
                state.currentPlaylist.push(preservedItem);
                newIndex = state.currentPlaylist.length - 1;
                state.currentPlaylistIndex = newIndex;
            }
        } else {
            console.log(`[定时刷新] 在新列表中找到当前频道，位置: ${newIndex}`);
            state.currentPlaylistIndex = newIndex;
            const newItem = state.currentPlaylist[newIndex];
            if (newItem.urls && newItem.urls.length > 0) {
                newItem.currentUrlIndex = oldItem ? oldItem.currentUrlIndex || 0 : 0;
                newItem.currentRound = oldItem ? oldItem.currentRound || 1 : 1;
            }
        }
        renderPlaylist(UI.playlistSearchInput.value);
        updatePlaylistHighlight();
        if (!UI.playlistContainer.classList.contains("hidden")) {
            const currentSearch = UI.playlistSearchInput.value;
            if (currentSearch) {
                renderPlaylist(currentSearch);
            }
            addRefreshIndicator();
        }
        showRefreshNotification(`播放列表已刷新: ${oldPlaylist.length} → ${newPlaylist.length} 个频道`);
        console.log(`[定时刷新] 播放列表刷新完成: ${oldPlaylist.length} → ${newPlaylist.length} 个频道`);
    }
    function addRefreshIndicator() {
        const oldIndicator = UI.playlistContainer.querySelector('.refresh-indicator');
        if (oldIndicator) {
            oldIndicator.remove();
        }
        const indicator = document.createElement('div');
        indicator.className = 'refresh-indicator';
        indicator.textContent = '刷新中...';
        indicator.style.cssText = `
            position: absolute;
            top: 10px;
            right: 10px;
            background: rgba(0, 100, 0, 0.8);
            color: white;
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 12px;
            z-index: 1002;
        `;
        UI.playlistContainer.appendChild(indicator);
        setTimeout(() => {
            if (indicator.parentNode) {
                indicator.parentNode.removeChild(indicator);
            }
        }, 1500);
    }
    function showRefreshNotification(message) {
        const oldNotifications = document.querySelectorAll('.refresh-notification');
        oldNotifications.forEach(n => n.remove());
        const notification = document.createElement("div");
        notification.className = "refresh-notification";
        notification.textContent = message;
        if (!document.querySelector('#refresh-notification-style')) {
            const style = document.createElement('style');
            style.id = 'refresh-notification-style';
            style.textContent = `
                @keyframes fadeInOut {
                    0% { opacity: 0; transform: translateY(-10px); }
                    10% { opacity: 1; transform: translateY(0); }
                    90% { opacity: 1; transform: translateY(0); }
                    100% { opacity: 0; transform: translateY(-10px); }
                }
                .refresh-notification {
                    pointer-events: none;
                }
            `;
            document.head.appendChild(style);
        }
        document.body.appendChild(notification);
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 3000);
    }
    function manualSwitchToNextSource() {
        if (state.currentPlaylistIndex === -1) return;
        const item = state.currentPlaylist[state.currentPlaylistIndex];
        if (!item || !item.urls || item.urls.length === 0) {
            showError("当前频道没有可用的源");
            return;
        }
        if (item.urls.length <= 1) {
            showNotification("当前频道只有一个源", 1500);
            return;
        }
        if (item.currentUrlIndex === undefined) item.currentUrlIndex = 0;
        if (item.currentRound === undefined) item.currentRound = 1;
        const nextIndex = (item.currentUrlIndex + 1) % item.urls.length;
        if (nextIndex === 0) {
            if (item.currentRound < CONFIG.MAX_RETRY_ROUNDS) {
                item.currentRound++;
            }
        }
        console.log(`[手动换源] 从源 ${item.currentUrlIndex + 1} 切换到源 ${nextIndex + 1} (轮次: ${item.currentRound}/${CONFIG.MAX_RETRY_ROUNDS})`);
        item.currentUrlIndex = nextIndex;
        const nextUrl = item.urls[nextIndex];
        // 检查黑名单
        if (checkUrlInBlacklist(nextUrl, "手动换源URL")) {
            // 如果被拦截，继续尝试下一个
            setTimeout(() => manualSwitchToNextSource(), 500);
            return;
        }
        showLoading(true);
        UI.errorMessage.style.display = "none";
        showNotification(`切换到源 ${nextIndex + 1}/${item.urls.length}`, 2000);
        destroyPlayer();
        checkAndInitPlayer(nextUrl);
        if (state.timers.load) clearTimeout(state.timers.load);
        state.timers.load = setTimeout(() => {
            console.error(`[手动换源] 加载超时 (${CONFIG.LOAD_TIMEOUT_MS}ms)，触发自动换源逻辑。`);
            tryNextRedundantUrl();
        }, CONFIG.LOAD_TIMEOUT_MS);
        setTimeout(updateInfoPanel, 500);
    }
    function showNotification(message, duration = 2000) {
        const oldNotification = document.querySelector('.source-notification');
        if (oldNotification) {
            oldNotification.remove();
        }
        const notification = document.createElement("div");
        notification.className = "source-notification";
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(0, 100, 200, 0.9);
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            z-index: 1000;
            font-size: 14px;
            animation: fadeInOut ${duration/1000}s ease-in-out;
        `;
        document.body.appendChild(notification);
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, duration);
    }
    function tryNextRedundantUrl() {
        if (state.currentPlaylistIndex === -1) return;
        const item = state.currentPlaylist[state.currentPlaylistIndex];
        if (!item || !item.urls || item.urls.length === 0) {
            showError("播放列表数据错误");
            return;
        }
        if (item.currentRound === undefined) item.currentRound = 1;
        if (item.currentUrlIndex === undefined) item.currentUrlIndex = 0;
        const nextIndex = item.currentUrlIndex + 1;
        if (nextIndex < item.urls.length) {
            item.currentUrlIndex = nextIndex;
        } else if (item.currentRound < CONFIG.MAX_RETRY_ROUNDS) {
            item.currentUrlIndex = 0;
            item.currentRound++;
            console.warn(`频道 [${item.title}] 开启第 ${item.currentRound}/${CONFIG.MAX_RETRY_ROUNDS} 轮尝试...`);
            showNotification(`第 ${item.currentRound} 轮尝试 (共 ${CONFIG.MAX_RETRY_ROUNDS} 轮)`, 2000);
        } else {
            if (state.timers.load) {
                clearTimeout(state.timers.load);
                state.timers.load = null;
            }
            destroyPlayer();
            state.isPlaying = false;
            UI.playPauseBtn.textContent = "▶";
            UI.playPauseBtn.title = "播放";
            showError(`频道 [${item.title || "未知"}] 无法播放或太过卡顿，请尝试其他频道。`);
            return;
        }
        const nextUrl = item.urls[item.currentUrlIndex];
        // 检查黑名单
        if (checkUrlInBlacklist(nextUrl, "自动换源URL")) {
            // 如果被拦截，继续尝试下一个
            setTimeout(() => tryNextRedundantUrl(), 500);
            return;
        }
        console.warn(`自动换源 (轮次:${item.currentRound}, 索引:${item.currentUrlIndex}): ${nextUrl}`);
        showNotification(`自动切换到源 ${item.currentUrlIndex + 1}/${item.urls.length}`, 1500);
        destroyPlayer();
        showLoading(true);
        UI.errorMessage.style.display = "none";
        checkAndInitPlayer(nextUrl);
        state.timers.load = setTimeout(() => {
            console.error(`加载超时 (${CONFIG.LOAD_TIMEOUT_MS}ms)，切换线路。`);
            tryNextRedundantUrl();
        }, CONFIG.LOAD_TIMEOUT_MS);
    }
    function playPlaylistItem(index) {
        if (index < 0 || index >= state.currentPlaylist.length) return;
        const item = state.currentPlaylist[index];
        const itemUrl = item.urls[0];
        // 检查URL是否在黑名单中
        if (checkUrlInBlacklist(itemUrl, "播放列表URL")) {
            return;
        }
        state.currentPlaylistIndex = index;
        item.currentUrlIndex = 0;
        item.currentRound = 1;
        state.currentChannelInfo = {
            title: item.title || "",
            originalIndex: index,
            urls: [...item.urls]
        };
        updatePlaylistHighlight();
        UI.videoInfo.textContent = item.title || decodeURIComponent(itemUrl);
        destroyPlayer();
        showLoading(true);
        UI.errorMessage.style.display = "none";
        checkAndInitPlayer(itemUrl);
        state.timers.load = setTimeout(() => {
            console.error(`加载超时 (${CONFIG.LOAD_TIMEOUT_MS}ms)，切换线路。`);
            tryNextRedundantUrl();
        }, CONFIG.LOAD_TIMEOUT_MS);
    }
    function renderPlaylist(searchTerm = "") {
        UI.playlistItems.innerHTML = "";
        const lowerTerm = searchTerm.toLowerCase();
        const fragment = document.createDocumentFragment();
        state.currentPlaylist.forEach((item, index) => {
            const channelName = item.title || `项目 ${index + 1}`;
            if (searchTerm && !channelName.toLowerCase().includes(lowerTerm)) {
                return;
            }
            const el = document.createElement("div");
            el.className = "playlist-item";
            if (index === state.currentPlaylistIndex) el.classList.add("active");
            el.textContent = channelName;
            el.dataset.index = index;
            el.onclick = () => playPlaylistItem(index);
            setupButtonHoverEffects(el);
            fragment.appendChild(el);
        });
        UI.playlistItems.appendChild(fragment);
    }
    function updatePlaylistHighlight() {
        const items = UI.playlistItems.children;
        for (let el of items) {
            if (parseInt(el.dataset.index) === state.currentPlaylistIndex) {
                el.classList.add("active");
                el.scrollIntoView({
                    behavior: "smooth",
                    block: "nearest"
                });
            } else {
                el.classList.remove("active");
            }
        }
    }
    function handlePlaylistSearch(e) {
        const term = e.target.value;
        if (term) UI.clearSearchBtn.classList.add("visible");
        else UI.clearSearchBtn.classList.remove("visible");
        if (state.timers.searchDebounce) clearTimeout(state.timers.searchDebounce);
        state.timers.searchDebounce = setTimeout(() => {
            renderPlaylist(term);
        }, CONFIG.SEARCH_DEBOUNCE_MS);
    }
    function clearSearch() {
        UI.playlistSearchInput.value = "";
        UI.clearSearchBtn.classList.remove("visible");
        renderPlaylist("");
    }
    function updateVideoInfoFromElement() {
        if (UI.videoPlayer.videoWidth && UI.videoPlayer.videoHeight) {
            state.streamInfo.resolution = `${UI.videoPlayer.videoWidth}x${UI.videoPlayer.videoHeight}`;
        }
        updateInfoPanel();
    }
    function updateResolutionFromHls(hlsPlayer, data) {
        if (data && data.levels && data.levels.length > 0) {
            const currentLevel = hlsPlayer.currentLevel >= 0 ? hlsPlayer.currentLevel : hlsPlayer.autoLevelEnabled ? hlsPlayer.autoLevelLast : 0;
            const levelData = data.levels[currentLevel];
            if (levelData && levelData.width) {
                state.streamInfo.resolution = `${levelData.width}x${levelData.height}`;
            }
        }
        updateInfoPanel();
    }
    function updateInfoPanel() {
        const lines = [
            `类型: ${state.streamInfo.type}`,
            `分辨率: ${state.streamInfo.resolution}`//,
            //`加载超时: ${Math.round(CONFIG.LOAD_TIMEOUT_MS/1000)}秒`,
            //`卡顿超时: ${Math.round(CONFIG.STALL_TIMEOUT_MS/1000)}秒`,
            //`最大重试: ${CONFIG.MAX_RETRY_ROUNDS}轮`
        ];
        if (state.isM3UPlaylist && state.currentPlaylistIndex >= 0) {
            const item = state.currentPlaylist[state.currentPlaylistIndex];
            if (item) {
                const totalUrls = item.urls ? item.urls.length : 0;
                const currentIndex = (item.currentUrlIndex || 0) + 1;
                const round = item.currentRound || 1;
                lines.push(`频道列表: ${state.currentPlaylistIndex + 1}/${state.currentPlaylist.length}`);
				lines.push(`加载超时: ${Math.round(CONFIG.LOAD_TIMEOUT_MS/1000)}秒`);
				lines.push(`卡顿超时: ${Math.round(CONFIG.STALL_TIMEOUT_MS/1000)}秒`);
				lines.push(`最大重试: ${CONFIG.MAX_RETRY_ROUNDS}轮`);
                if (totalUrls > 1) {
                    lines.push(`源: ${currentIndex}/${totalUrls}`);
                    lines.push(`轮次: ${round}/${CONFIG.MAX_RETRY_ROUNDS}`);
                }
                if (CONFIG.AUTO_REFRESH_ENABLED && state.timers.refreshPlaylist) {
                    lines.push(`列表刷新: ${Math.round(CONFIG.PLAYLIST_REFRESH_INTERVAL/60000)}分钟`);
                }
                if (item.title && item.title.includes("(旧列表)")) {
                    lines.push(`状态: 来自旧列表`);
                }
            }
        }
        // 添加黑名单信息
        if (state.blacklist.length > 0) {
            lines.push(`黑名单: ${state.blacklist.length}个规则`);
        }
        UI.infoPanel.innerHTML = lines.join("<br>");
    }
    function toggleVideoInfo() {
        updateInfoPanel();
        const currentDisplay = UI.infoPanel.style.display;
        UI.infoPanel.style.display = currentDisplay === "none" ? "block" : "none";
    }
    function updateProgress() {
        const { currentTime, duration } = UI.videoPlayer;
        if (duration && !isNaN(duration) && duration !== Infinity) {
            const percent = currentTime / duration * 100;
            UI.progressBar.style.width = percent + "%";
            UI.timeDisplay.textContent = `${formatTime(currentTime)} / ${formatTime(duration)}`;
        } else {
            UI.progressBar.style.width = "100%";
            UI.timeDisplay.textContent = `${formatTime(currentTime)} / Live`;
        }
    }
    function seek(e) {
        if (!UI.videoPlayer.duration || UI.videoPlayer.duration === Infinity) return;
        const rect = UI.progress.getBoundingClientRect();
        const pos = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        UI.videoPlayer.currentTime = pos * UI.videoPlayer.duration;
    }
    function adjustVolume(e) {
        const rect = UI.volumeSlider.getBoundingClientRect();
        let volume = (e.clientX - rect.left) / rect.width;
        volume = Math.max(0, Math.min(1, volume));
        UI.videoPlayer.volume = volume;
        UI.volumeProgress.style.width = volume * 100 + "%";
        updateVolumeIcon();
        chrome.storage.local.set({
            volume: volume
        });
    }
    function updateVolumeIcon() {
        const v = UI.videoPlayer.volume;
        if (UI.videoPlayer.muted || v === 0) UI.volumeBtn.textContent = "🔇";
        else if (v < .5) UI.volumeBtn.textContent = "🔉";
        else UI.volumeBtn.textContent = "🔊";
    }
    function toggleMute() {
        UI.videoPlayer.muted = !UI.videoPlayer.muted;
        updateVolumeIcon();
    }
    function toggleFullscreen() {
        const container = document.querySelector(".player-container");
        if (!document.fullscreenElement) {
            (container.requestFullscreen || container.webkitRequestFullscreen || container.msRequestFullscreen).call(container);
        } else {
            (document.exitFullscreen || document.webkitExitFullscreen || document.msExitFullscreen).call(document);
        }
    }
    function togglePlayPause() {
        if (UI.videoPlayer.paused) attemptPlay();
        else UI.videoPlayer.pause();
    }
    function togglePlaylistUI(show) {
        const shouldShow = show !== undefined ? show : !UI.playlistContainer.classList.contains("hidden") === false;
        UI.playlistContainer.classList.toggle("hidden", !shouldShow);
    }
    function showControls() {
        UI.controls.classList.remove("hidden");
        if (state.timers.controls) clearTimeout(state.timers.controls);
        state.timers.controls = setTimeout(() => {
            if (state.isPlaying) {
                UI.controls.classList.add("hidden");
            }
        }, 30000);
    }
    function initGlobalEvents() {
        document.addEventListener("mousemove", showControls);
        UI.playPauseBtn.onclick = togglePlayPause;
        UI.prevChannelBtn.onclick = function(e) {
            e.stopPropagation();
            switchToPrevChannel();
        };
        UI.nextChannelBtn.onclick = function(e) {
            e.stopPropagation();
            switchToNextChannel();
        };
        UI.volumeBtn.onclick = toggleMute;
        UI.volumeSlider.onclick = adjustVolume;
        UI.fullscreenBtn.onclick = toggleFullscreen;
        UI.backBtn.onclick = () => window.close();
        UI.infoBtn.onclick = toggleVideoInfo;
        UI.playlistBtn.onclick = () => togglePlaylistUI();
        UI.closePlaylistBtn.onclick = () => togglePlaylistUI(false);
        UI.progress.onclick = seek;
        UI.playlistSearchInput.oninput = handlePlaylistSearch;
        UI.clearSearchBtn.onclick = clearSearch;
        UI.switchSourceBtn.onclick = function(e) {
            e.stopPropagation();
            manualSwitchToNextSource();
        };
        UI.playlistContainer.onmouseleave = () => {
            if (document.activeElement !== UI.playlistSearchInput) {
                state.timers.hidePlaylist = setTimeout(() => togglePlaylistUI(false), 300);
            }
        };
        UI.playlistContainer.onmouseenter = () => {
            if (state.timers.hidePlaylist) clearTimeout(state.timers.hidePlaylist);
        };
    }
    window.addEventListener('beforeunload', function() {
        if (state.timers.refreshPlaylist) {
            clearTimeout(state.timers.refreshPlaylist);
            console.log('[清理] 播放列表刷新定时器已清理');
        }
        if (state.timers.load) {
            clearTimeout(state.timers.load);
            console.log('[清理] 加载定时器已清理');
        }
        if (state.timers.stall) {
            clearTimeout(state.timers.stall);
            console.log('[清理] 卡顿定时器已清理');
        }
    });
    init();
});