document.addEventListener("DOMContentLoaded", function() {
    let videoUrl = "";
    const urlParams = new URLSearchParams(window.location.search);
    const queryUrl = urlParams.get("url");
    const hashUrl = window.location.hash.substring(1);
    videoUrl = queryUrl || hashUrl;
    const videoPlayer = document.getElementById("videoPlayer");
    const videoInfo = document.getElementById("videoInfo");
    const backBtn = document.getElementById("backBtn");
    const playPauseBtn = document.getElementById("playPauseBtn");
    const progress = document.getElementById("progress");
    const progressBar = document.getElementById("progressBar");
    const timeDisplay = document.getElementById("time");
    const volumeBtn = document.getElementById("volumeBtn");
    const volumeSlider = document.getElementById("volumeSlider");
    const volumeProgress = document.getElementById("volumeProgress");
    const fullscreenBtn = document.getElementById("fullscreenBtn");
    const loading = document.getElementById("loading");
    const errorMessage = document.getElementById("errorMessage");
    const controls = document.getElementById("controls");
    const playlistBtn = document.getElementById("playlistBtn");
    const playlistContainer = document.getElementById("playlist-container");
    const closePlaylistBtn = document.getElementById("closePlaylistBtn");
    const playlistItems = document.getElementById("playlist-items");
    const playlistSearchInput = document.getElementById("playlist-search-input");
    const clearSearchBtn = document.getElementById("clearSearchBtn");
    let player = null;
    let isPlaying = false;
    let controlsTimeout;
    let videoContainer = document.querySelector(".video-container");
    let loadTimeoutTimer = null;
    const LOAD_TIMEOUT_MS = 3e3;
    let stallTimeoutTimer = null;
    const STALL_TIMEOUT_MS = 5e3;

    // --- 新增配置：自定义遍历轮数 ---
    const MAX_RETRY_ROUNDS = 3; 
    // ----------------------------

    let currentPlaylist = [];
    let currentPlaylistIndex = -1;
    let isM3UPlaylist = false;
    let baseUrl = "";
    const infoBtn = document.createElement("button");
    infoBtn.className = "info-btn";
    infoBtn.innerHTML = "ℹ";
    infoBtn.style.cssText = "background:none; border:none; color:white; cursor:pointer; margin-left:10px;";
    document.querySelector(".volume-container").insertAdjacentElement("afterend", infoBtn);
    const infoPanel = document.createElement("div");
    infoPanel.className = "info-panel";
    infoPanel.style.cssText = "display:none; position:absolute; bottom:60px; right:10px; background:rgba(0,0,0,0.8); padding:10px; border-radius:4px; font-size:12px;";
    videoContainer.appendChild(infoPanel);
    chrome.storage.local.get([ "volume" ], function(result) {
        if (result.volume !== undefined) {
            videoPlayer.volume = result.volume;
            volumeProgress.style.width = result.volume * 100 + "%";
            updateVolumeIcon();
        }
    });
    let streamInfo = {
        resolution: "未知",
        type: "未知"
    };
    function initPlayer() {
        if (!videoUrl) {
            showError("无效的视频链接");
            return;
        }
        videoInfo.textContent = decodeURIComponent(videoUrl);
        showLoading(true);
        try {
            const url = new URL(videoUrl);
            baseUrl = url.href.substring(0, url.href.lastIndexOf("/") + 1);
        } catch (e) {
            console.error("解析URL失败:", e);
            baseUrl = "";
        }
        checkAndInitPlayer(videoUrl);
    }

    // --- 修改逻辑：支持多轮遍历 ---
    function tryNextRedundantUrl() {
        if (currentPlaylistIndex === -1) return;
        const item = currentPlaylist[currentPlaylistIndex];
        if (!item || !item.urls || item.urls.length === 0) {
            showError("播放列表项数据无效或缺少 URL。");
            return;
        }

        // 初始化轮次记录
        if (item.currentRound === undefined) {
            item.currentRound = 1;
        }

        const nextIndex = item.currentUrlIndex + 1;

        if (nextIndex < item.urls.length) {
            // 同一轮内的下一个源
            item.currentUrlIndex = nextIndex;
        } else if (item.currentRound < MAX_RETRY_ROUNDS) {
            // 开启新的一轮遍历
            item.currentUrlIndex = 0;
            item.currentRound++;
            console.warn(`频道 [${item.title}] 所有源已尝试，开始第 ${item.currentRound}/${MAX_RETRY_ROUNDS} 轮尝试...`);
        } else {
            // 超过最大轮数，停止遍历
            showError(`频道 [${item.title || "未知"}] 无法播放或太过卡顿，请观看其他频道。`);
            return;
        }

        const nextUrl = item.urls[item.currentUrlIndex];
        console.warn(`尝试 URL (轮次:${item.currentRound}, 索引:${item.currentUrlIndex + 1}): ${nextUrl}`);

        if (player) {
            if (player.destroy) player.destroy();
            player = null;
        }
        videoPlayer.removeAttribute("src");
        showLoading(true);
        errorMessage.style.display = "none";
        checkAndInitPlayer(nextUrl);
    }

    function initM3UPlaylist() {
        isM3UPlaylist = true;
        const parser = new M3UParser;
        parser.parseFromUrl(videoUrl).then(playlist => {
            if (playlist.length === 0) {
                showError("播放列表为空");
                return;
            }
            playlist.forEach(item => {
                const urlsToProcess = item.urls && item.urls.length > 0 ? item.urls : [ item.url ].filter(u => u);
                item.urls = urlsToProcess.map(url => {
                    if (!url.startsWith("http") && !url.startsWith("//")) {
                        return M3UParser.resolveUrl(baseUrl, url);
                    }
                    return url;
                });
                if (item.urls.length === 0) {
                    item.skip = true;
                }
            });
            currentPlaylist = playlist.filter(item => !item.skip);
            if (currentPlaylist.length === 0) {
                showError("播放列表解析后无有效项目。");
                return;
            }
            renderPlaylist();
            playPlaylistItem(0);
            togglePlaylist(true);
        }).catch(error => {
            console.error("解析 M3U 文件失败:", error);
            showError("解析播放列表失败: " + error.message);
        });
    }
    function renderPlaylist(searchTerm = "") {
        playlistItems.innerHTML = "";
        const lowerSearchTerm = searchTerm.toLowerCase();
        currentPlaylist.forEach((item, index) => {
            const itemElement = document.createElement("div");
            itemElement.className = "playlist-item";
            if (index === currentPlaylistIndex) {
                itemElement.classList.add("active");
            }
            const channelName = item.title || `项目 ${index + 1}`;
            itemElement.textContent = channelName;
            if (searchTerm) {
                if (!channelName.toLowerCase().includes(lowerSearchTerm)) {
                    itemElement.classList.add("hidden");
                }
            }
            itemElement.addEventListener("click", () => {
                playPlaylistItem(index);
            });
            itemElement.dataset.index = index;
            itemElement.dataset.channelName = channelName;
            playlistItems.appendChild(itemElement);
        });
    }
    function searchPlaylist(searchTerm) {
        if (searchTerm) {
            clearSearchBtn.classList.add("visible");
        } else {
            clearSearchBtn.classList.remove("visible");
        }
        if (playlistItems.children.length > 0) {
            Array.from(playlistItems.children).forEach(item => {
                const channelName = item.dataset.channelName || "";
                if (searchTerm && !channelName.toLowerCase().includes(searchTerm.toLowerCase())) {
                    item.classList.add("hidden");
                } else {
                    item.classList.remove("hidden");
                }
            });
        } else {
            renderPlaylist(searchTerm);
        }
    }
    function clearSearch() {
        playlistSearchInput.value = "";
        clearSearchBtn.classList.remove("visible");
        searchPlaylist("");
    }

    // --- 修改逻辑：播放新频道时重置计数 ---
    function playPlaylistItem(index) {
        if (index < 0 || index >= currentPlaylist.length) return;
        errorMessage.style.display = "none";
        currentPlaylistIndex = index;
        const item = currentPlaylist[index];

        // 重置索引与轮次
        item.currentUrlIndex = 0;
        item.currentRound = 1;

        const itemUrl = item.urls && item.urls.length > 0 ? item.urls[0] : item.url;
        if (!itemUrl) {
            showError(`项目 ${index + 1} 缺少 URL.`);
            return;
        }
        document.querySelectorAll(".playlist-item").forEach((el, i) => {
            el.classList.toggle("active", i === index);
        });
        if (player) {
            if (player.destroy) player.destroy();
            player = null;
        }
        videoPlayer.removeAttribute("src");
        if (loadTimeoutTimer) clearTimeout(loadTimeoutTimer);
        loadTimeoutTimer = null;
        if (stallTimeoutTimer) clearTimeout(stallTimeoutTimer);
        stallTimeoutTimer = null;
        streamInfo = {
            resolution: "未知",
            type: "未知"
        };
        videoInfo.textContent = item.title || decodeURIComponent(itemUrl);
        showLoading(true);
        checkAndInitPlayer(itemUrl);
        if (isM3UPlaylist) {
            loadTimeoutTimer = setTimeout(() => {
                console.error(`加载元数据超时 (${LOAD_TIMEOUT_MS}ms)，尝试下一个冗余 URL。`);
                tryNextRedundantUrl();
            }, LOAD_TIMEOUT_MS);
        }
    }
    
    function checkAndInitPlayer(url) {
        const lowerUrl = url.toLowerCase();
        if (/(?:\.(flv|m3u8|m3u)|#m3u8|#m3u)([?#].*)?$/.test(lowerUrl)) {
            initPlayerWithUrl(url);
        } else {
            showLoading(true);
            console.log("检测URL重定向及 Content-Type:", url);
            chrome.runtime.sendMessage({
                action: "checkRedirect",
                url: url
            }, response => {
                if (response && response.success) {
                    const finalUrl = response.finalUrl;
                    const contentType = response.contentType ? response.contentType.toLowerCase() : "";
                    console.log("重定向后的URL:", finalUrl);
                    console.log("Content-Type:", contentType);
                    initPlayerWithUrl(finalUrl, contentType);
                } else {
                    console.error("重定向检测失败:", response ? response.error : "未知错误");
                    initPlayerWithUrl(url);
                }
            });
        }
    }
    function initPlayerWithUrl(url, contentType = "") {
        const lowerUrl = url.toLowerCase();
        const isHlsContentType = contentType.includes("mpegurl") || contentType.includes("hls") || contentType.includes("text/html") || contentType.includes("text/plain") || contentType.includes("application/octet-stream");
        if (isHlsContentType) {
            streamInfo.type = "HLS (Type/Fallback)";
            initHlsPlayerWithUrl(url);
        } else if (/\.flv([?#].*)?$/.test(lowerUrl)) {
            streamInfo.type = "FLV";
            initFlvPlayerWithUrl(url);
        } else if (/(?:[.]m3u8|#m3u8)([?#].*)?$/.test(lowerUrl)) {
            streamInfo.type = "HLS";
            initHlsPlayerWithUrl(url);
        } else if (/(?:[.]m3u|#m3u)([?#].*)?$/.test(lowerUrl)) {
            streamInfo.type = "M3U";
            initM3UPlaylist();
        } else {
            streamInfo.type = "原生";
            initNativePlayerWithUrl(url);
        }
    }
    function initFlvPlayerWithUrl(url) {
        if (flvjs.isSupported()) {
            player = flvjs.createPlayer({
                type: "flv",
                url: url
            });
            player.attachMediaElement(videoPlayer);
            player.load();
            player.on(flvjs.Events.METADATA_ARRIVED, function(metadata) {
                if (loadTimeoutTimer) clearTimeout(loadTimeoutTimer);
                loadTimeoutTimer = null;
                if (metadata && metadata.onMetaData) {
                    const meta = metadata.onMetaData;
                    if (meta.width && meta.height) {
                        streamInfo.resolution = `${meta.width}x${meta.height}`;
                    }
                    updateInfoPanel();
                }
            });
            player.on(flvjs.Events.ERROR, function(errorType, errorDetail) {
                console.error("FLV播放错误:", errorType, errorDetail);
                if (isM3UPlaylist) {
                    tryNextRedundantUrl();
                } else {
                    showError("FLV播放错误: " + errorType);
                }
            });
            videoPlayer.addEventListener("loadedmetadata", function() {
                if (loadTimeoutTimer) clearTimeout(loadTimeoutTimer);
                loadTimeoutTimer = null;
                showLoading(false);
                updateVideoInfo();
                play();
            });
            videoPlayer.addEventListener("error", function() {
                if (isM3UPlaylist && !player) {
                    tryNextRedundantUrl();
                } else if (!isM3UPlaylist) {
                    showError("视频加载失败");
                }
            });
        } else {
            showError("您的浏览器不支持FLV播放");
        }
    }
    function initHlsPlayerWithUrl(url) {
        if (Hls.isSupported()) {
            player = new Hls({
                debug: false,
                capLevelToPlayerSize: true,
                autoLevelEnabled: true,
                fragLoadingMaxRetry: 1,
                fragLoadingRetryDelay: 500
            });
            player.loadSource(url);
            player.attachMedia(videoPlayer);
            player.on(Hls.Events.MANIFEST_PARSED, function(event, data) {
                if (loadTimeoutTimer) clearTimeout(loadTimeoutTimer);
                loadTimeoutTimer = null;
                console.log("HLS Manifest:", data);
                showLoading(false);
                if (data.levels && data.levels.length > 0) {
                    const currentLevel = player.currentLevel >= 0 ? player.currentLevel : player.autoLevelEnabled ? player.autoLevelLast : 0;
                    const levelData = data.levels[currentLevel];
                    if (levelData && levelData.width && levelData.height) {
                        streamInfo.resolution = `${levelData.width}x${levelData.height}`;
                        updateInfoPanel();
                    }
                }
                play();
            });
            videoPlayer.addEventListener("loadeddata", function() {
                updateVideoInfoFromElement();
            });
            player.on(Hls.Events.ERROR, function(event, data) {
                if (data.fatal) {
                    console.error("HLS播放致命错误:", data.type, data.details);
                    if (isM3UPlaylist) {
                        tryNextRedundantUrl();
                    } else {
                        showError("HLS播放错误: " + data.details);
                    }
                }
            });
        } else if (videoPlayer.canPlayType("application/vnd.apple.mpegurl")) {
            videoPlayer.src = url;
            videoPlayer.addEventListener("loadedmetadata", function() {
                if (loadTimeoutTimer) clearTimeout(loadTimeoutTimer);
                loadTimeoutTimer = null;
                showLoading(false);
                play();
            });
            videoPlayer.addEventListener("loadeddata", function() {
                updateVideoInfoFromElement();
            });
            videoPlayer.addEventListener("error", function() {
                if (isM3UPlaylist) {
                    tryNextRedundantUrl();
                } else {
                    showError("视频加载失败");
                }
            });
        } else {
            showError("您的浏览器不支持HLS播放");
        }
    }
    function initNativePlayerWithUrl(url) {
        const lowerUrl = url.toLowerCase();
        if (/\.mp4([?#].*)?$/.test(lowerUrl)) {
            streamInfo.type = "MP4";
        } else if (/\.webm([?#].*)?$/.test(lowerUrl)) {
            streamInfo.type = "WebM";
        } else if (/\.ogg([?#].*)?$/.test(lowerUrl) || /\.ogv([?#].*)?$/.test(lowerUrl)) {
            streamInfo.type = "OGG";
        } else {
            streamInfo.type = "未知";
        }
        videoPlayer.src = url;
        videoPlayer.addEventListener("loadedmetadata", function() {
            if (loadTimeoutTimer) clearTimeout(loadTimeoutTimer);
            loadTimeoutTimer = null;
            showLoading(false);
            updateVideoInfoFromElement();
            play();
        });
        videoPlayer.addEventListener("error", function() {
            if (isM3UPlaylist) {
                tryNextRedundantUrl();
            } else {
                showError("不支持的视频格式或视频加载失败");
            }
        });
    }
    function updateVideoInfoFromElement() {
        if (videoPlayer.videoWidth && videoPlayer.videoHeight) {
            streamInfo.resolution = `${videoPlayer.videoWidth}x${videoPlayer.videoHeight}`;
        }
        updateInfoPanel();
    }
    function updateInfoPanel() {
        const info = [];
        info.push(`类型: ${streamInfo.type}`);
        info.push(`分辨率: ${streamInfo.resolution}`);
        if (isM3UPlaylist && currentPlaylistIndex >= 0) {
            const item = currentPlaylist[currentPlaylistIndex];
            const totalUrls = item.urls ? item.urls.length : 1;
            const currentIndex = item.currentUrlIndex !== undefined ? item.currentUrlIndex + 1 : 1;
            info.push(`频道列表: ${currentPlaylistIndex + 1}/${currentPlaylist.length}`);
            if (totalUrls > 1) {
                info.push(`当前频道源: ${currentIndex}/${totalUrls}`);
                // 新增：显示重试轮次
                if (item.currentRound > 1) {
                    info.push(`重试轮次: ${item.currentRound}/${MAX_RETRY_ROUNDS}`);
                }
            }
        }
        infoPanel.innerHTML = info.join("<br>");
    }
    function updateVideoInfo() {
        if (player) {
            if (streamInfo.type.includes("HLS") && player.levels) {
                const currentLevel = player.currentLevel >= 0 ? player.currentLevel : player.autoLevelEnabled ? player.autoLevelLast : 0;
                if (player.levels[currentLevel]) {
                    const levelData = player.levels[currentLevel];
                    if (levelData.width && levelData.height) {
                        streamInfo.resolution = `${levelData.width}x${levelData.height}`;
                    }
                }
            }
        }
        updateVideoInfoFromElement();
    }
    function showLoading(show) {
        loading.style.display = show ? "block" : "none";
    }
    function showError(message) {
        showLoading(false);
        errorMessage.textContent = message;
        errorMessage.style.display = "block";
    }
    function togglePlayPause() {
        if (videoPlayer.paused) {
            play();
        } else {
            pause();
        }
    }
    let isFirstPlay = true;
    function play() {
        if (isFirstPlay && !document.fullscreenElement) {
            const container = document.querySelector(".player-container");
            if (container.requestFullscreen) {
                container.requestFullscreen();
            } else if (container.webkitRequestFullscreen) {
                container.webkitRequestFullscreen();
            } else if (container.msRequestFullscreen) {
                container.msRequestFullscreen();
            }
            isFirstPlay = false;
        }
        videoPlayer.play().then(() => {
            isPlaying = true;
            playPauseBtn.textContent = "❚❚";
        }).catch(error => {
            console.error("播放失败:", error);
        });
    }
    function pause() {
        videoPlayer.pause();
        isPlaying = false;
        playPauseBtn.textContent = "▶";
    }
    function updateProgress() {
        if (videoPlayer.duration && !isNaN(videoPlayer.duration) && videoPlayer.duration !== Infinity) {
            const percent = videoPlayer.currentTime / videoPlayer.duration * 100;
            progressBar.style.width = percent + "%";
            const currentTime = formatTime(videoPlayer.currentTime);
            const duration = formatTime(videoPlayer.duration);
            timeDisplay.textContent = `${currentTime} / ${duration}`;
        } else {
            progressBar.style.width = "100%";
            const currentTime = formatTime(videoPlayer.currentTime);
            timeDisplay.textContent = `${currentTime} / Live`;
        }
    }
    function formatTime(seconds) {
        if (seconds === Infinity) return "Live";
        const minutes = Math.floor(seconds / 60);
        seconds = Math.floor(seconds % 60);
        return `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
    }
    function seek(e) {
        if (videoPlayer.duration === Infinity || isNaN(videoPlayer.duration)) return;
        const rect = progress.getBoundingClientRect();
        const pos = (e.clientX - rect.left) / rect.width;
        videoPlayer.currentTime = pos * videoPlayer.duration;
    }
    function adjustVolume(e) {
        const rect = volumeSlider.getBoundingClientRect();
        let volume = (e.clientX - rect.left) / rect.width;
        volume = Math.max(0, Math.min(1, volume));
        videoPlayer.volume = volume;
        volumeProgress.style.width = volume * 100 + "%";
        updateVolumeIcon();
        chrome.storage.local.set({
            volume: volume
        });
    }
    function updateVolumeIcon() {
        if (videoPlayer.muted || videoPlayer.volume === 0) {
            volumeBtn.textContent = "🔇";
        } else if (videoPlayer.volume < .5) {
            volumeBtn.textContent = "🔉";
        } else {
            volumeBtn.textContent = "🔊";
        }
    }
    function toggleMute() {
        videoPlayer.muted = !videoPlayer.muted;
        updateVolumeIcon();
    }
    function toggleFullscreen() {
        const container = document.querySelector(".player-container");
        if (!document.fullscreenElement) {
            if (container.requestFullscreen) {
                container.requestFullscreen();
            } else if (container.webkitRequestFullscreen) {
                container.webkitRequestFullscreen();
            } else if (container.msRequestFullscreen) {
                container.msRequestFullscreen();
            }
        } else {
            if (document.exitFullscreen) {
                document.exitFullscreen();
            } else if (document.webkitExitFullscreen) {
                document.webkitExitFullscreen();
            } else if (document.msExitFullscreen) {
                document.msExitFullscreen();
            }
        }
    }
    function toggleVideoInfo() {
        updateInfoPanel();
        infoPanel.style.display = infoPanel.style.display === "none" ? "block" : "none";
    }
    function togglePlaylist(show) {
        if (show === undefined) {
            playlistContainer.classList.toggle("hidden");
        } else {
            playlistContainer.classList.toggle("hidden", !show);
        }
    }
    function showControls() {
        controls.classList.remove("hidden");
        clearTimeout(controlsTimeout);
        controlsTimeout = setTimeout(() => {
            if (isPlaying) {
                controls.classList.add("hidden");
            }
        }, 3e3);
    }
    let hidePlaylistTimeout;
    playlistContainer.addEventListener("mouseleave", () => {
        if (document.activeElement !== playlistSearchInput) {
            hidePlaylistTimeout = setTimeout(() => {
                togglePlaylist(false);
            }, 300);
        }
    });
    playlistContainer.addEventListener("mouseenter", () => {
        if (hidePlaylistTimeout) {
            clearTimeout(hidePlaylistTimeout);
        }
    });
    playPauseBtn.addEventListener("click", togglePlayPause);
    progress.addEventListener("click", seek);
    volumeBtn.addEventListener("click", toggleMute);
    volumeSlider.addEventListener("click", adjustVolume);
    fullscreenBtn.addEventListener("click", toggleFullscreen);
    backBtn.addEventListener("click", () => window.close());
    infoBtn.addEventListener("click", toggleVideoInfo);
    playlistBtn.addEventListener("click", () => togglePlaylist());
    closePlaylistBtn.addEventListener("click", () => togglePlaylist(false));
    playlistSearchInput.addEventListener("input", e => {
        searchPlaylist(e.target.value);
    });
    clearSearchBtn.addEventListener("click", clearSearch);
    videoPlayer.addEventListener("timeupdate", updateProgress);
    videoPlayer.addEventListener("play", () => {
        isPlaying = true;
        playPauseBtn.textContent = "❚❚";
    });
    videoPlayer.addEventListener("pause", () => {
        isPlaying = false;
        playPauseBtn.textContent = "▶";
    });
    videoPlayer.addEventListener("volumechange", updateVolumeIcon);
    videoPlayer.addEventListener("ended", function() {
        if (isM3UPlaylist && currentPlaylistIndex < currentPlaylist.length - 1) {
            playPlaylistItem(currentPlaylistIndex + 1);
        }
    });
    videoPlayer.addEventListener("waiting", function() {
        if (isM3UPlaylist && isPlaying) {
            console.warn(`视频等待数据（卡顿），启动停滞超时计时器 (${STALL_TIMEOUT_MS}ms)...`);
            if (stallTimeoutTimer) clearTimeout(stallTimeoutTimer);
            stallTimeoutTimer = setTimeout(() => {
                console.error("播放停滞超时（Stall Timeout），尝试下一个冗余 URL。");
                tryNextRedundantUrl();
            }, STALL_TIMEOUT_MS);
        }
    });
    videoPlayer.addEventListener("playing", function() {
        if (stallTimeoutTimer) {
            console.log("视频恢复播放，清除停滞超时计时器。");
            clearTimeout(stallTimeoutTimer);
            stallTimeoutTimer = null;
        }
    });
    document.addEventListener("mousemove", showControls);
    initPlayer();
});