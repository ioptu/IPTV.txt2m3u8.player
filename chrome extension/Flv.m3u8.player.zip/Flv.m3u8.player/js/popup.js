document.addEventListener("DOMContentLoaded", function() {
    const videoUrlInput = document.getElementById("videoUrl");
    const playBtn = document.getElementById("playBtn");
    const settingsBtn = document.getElementById("settingsBtn");
    playBtn.addEventListener("click", function() {
        const url = videoUrlInput.value.trim();
        if (url) {
            playVideo(url);
        } else {
            alert("请输入有效的视频链接");
        }
    });
    function playVideo(url) {
        chrome.tabs.create({
            url: chrome.runtime.getURL("player.html") + "?url=" + encodeURIComponent(url)
        });
    }
    settingsBtn.addEventListener("click", function() {
        alert("设置功能将在后续版本中提供");
    });
});